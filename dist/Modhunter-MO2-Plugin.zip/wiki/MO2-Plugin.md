# 🛡 MO2 Plugin

The MO2 plugin is a Python tool targeting Mod Organizer 2 2.5.x. It depends on its host's `mobase` and PyQt6 but **not** on Electron or a separate web app.

## Native capabilities

- Reads the **active MO2 profile** with stable mod identities, priorities, group separators, versions, Nexus IDs and installed state.
- Checks update evidence, supports quick/local and deeper Nexus scans, and reports ambiguous version comparisons as unresolved rather than safe.
- Sends an exact user-selected Nexus file to the MO2 download manager, then hands installation to MO2's own FOMOD/overwrite prompts.
- Backs up text load-order/profile files before an explicit installation.
- **Reveal in MO2:** selects and scrolls to the exact mod, preserving MO2's native list sorting, drag-and-drop and custom column behavior.
- Tracks profile-specific verified version-change events, achievements, boss bounties and Forge Sigils.
- Serves its own authenticated dashboard through a random loopback port.

## Authentication and control

The HTTP service binds **127.0.0.1 only**. It rejects nonlocal hosts, cross-origin state-changing requests and commands without the generated session token. Privileged MO2 commands are dispatched to its Qt UI thread. Nexus API keys are session-only, not saved in the game or Electron app.

## Exact update reward flow

1. Native profile snapshot identifies a known installed version.
2. A fresh confirmed update candidate becomes a named boss in the game's Unfinished Bestiary.
3. You defeat the boss. This records a *pending bounty* but does not fabricate a mod installation.
4. You use **Reveal in MO2**, select the correct release and install it with MO2.
5. MO2 observes the new version against the original version. Only then does it mint normal Chronicle XP, Forge Sigils and the special bounty bonus.
6. An already-awarded version cannot be farmed by reinstalling it.

## Compatibility

Skyrim Special Edition 1.5.97 and modern AE/NG builds can require different SKSE DLLs and Address Library variants. A warning is a request to inspect the **specific file** rather than assume all files under a mod are compatible. Other games are supported where MO2 and Nexus metadata are available, but full parity has not been certified.

**Native Windows MO2 test status: not yet verified.** See [[Compatibility and Safety]] and [[Development and Testing]].
