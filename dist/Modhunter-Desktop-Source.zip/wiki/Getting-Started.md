# ⚔ Getting Started

> **First choose your launch mode.** You can change modes later, and none is mandatory for the others.

## Launch the standalone HTML (zero installation)

1. Download [`Modhunter.html`](https://github.com/Herbertofury/Modhunter/raw/refs/heads/main/web/Modhunter.html).
2. Open it with Opera GX, Chrome or another current Chromium browser.
3. Click **Modhunter Siege** or **Survival Realm**. Each opens its own tab.
4. Progress is stored locally in your browser for offline practice. Backup your progress from the dashboard.

A standalone HTML opened locally **cannot** read or change MO2 files. Its sample load order contains 227 mods and 115 section headers for demonstration.

## Launch the MO2 plugin

1. Download [`Modhunter-MO2-Plugin.zip`](https://github.com/Herbertofury/Modhunter/raw/refs/heads/main/dist/Modhunter-MO2-Plugin.zip).
2. Extract and run `Install_to_MO2.bat`, targeting the folder containing `ModOrganizer.exe`.
3. Restart Mod Organizer 2 and choose **Tools → Update Arsenal - Quest Board**.
4. The plugin opens its own browser dashboard on a random **127.0.0.1** port; no desktop app required.
5. MO2 remains in charge of install prompts, FOMOD selection, conflict handling and load order. The app can select an exact mod row for you.

## Launch the optional desktop app

1. Download [`Modhunter-Desktop-Source.zip`](https://github.com/Herbertofury/Modhunter/raw/refs/heads/main/dist/Modhunter-Desktop-Source.zip).
2. Install [Node.js](https://nodejs.org/) if it is not present, then run `desktop/Run_ModHunter.bat`.
3. Use the native tab bar to open **Mods**, **Siege** and **Realm**.
4. Optional live connection: launch the MO2 plugin, copy its `http://127.0.0.1:PORT/` address and paste it into **Connect** in the desktop tab bar.
5. **Unlink** safely returns to practice without changing MO2.

The development package contains an Electron project with a reproducible Windows build script, **not** a pre-verified Windows `.exe`.

## First adventure

Start with **Modhunter Siege → The Unfinished Atlas**. Pick Frostfall Expanse, The Last Bell of Winter, Wayfarer tier and a hero. Move with WASD, collect gems, choose upgrades with 1/2/3, dodge with Space, release the ultimate with R, pause with Escape. Clear contracts to unlock further chapters and earn game-only Legacy Embers.

Read [[Atlas Campaign]], [[Unfinished Bestiary]] and [[Rewards and Integrity]] for progression and the MO2 update loop.
