# MODHUNTER / ONE COMMAND CENTER

PRIMARY MISSION: Keep your real Mod Organizer 2 mods up to date.

This is one merged product containing Questbound, AetherFX, Shiverfell,
Mythforge, Modhunter Siege, Atlas and the full Update Workshop.

## Three independent ways to start

1. Standalone: open Modhunter.html. Offline review, quests, FX, survival,
   Siege and Atlas run without installing any other component.
2. Desktop: run Desktop/Run_ModHunter.bat on Windows with Node.js installed.
   Native tabs run the same HTML; optional read-only MO2 profile import works
   without the MO2 Python plugin.
3. MO2 plugin: run MO2/Install_to_MO2.bat and choose an MO2 installation.
   Start Tools -> Update Arsenal - Quest Board in MO2. The plugin's own
   dashboard reads the real active profile, scans mods and downloads reviewed
   archives into MO2. Desktop installation is not required.

Optionally connect the desktop app to the MO2 plugin's local session
for the same authenticated live profile in native Chromium tabs.

## First full update
Select active MO2 profile and correct game runtime; choose Check all mod
sources; review newest compatible Nexus or public GitHub release files;
queue reviewed downloads through MO2; install using its regular prompts;
then refresh and re-scan. Unverified private-provider pages remain manual.
No unattended installations. MO2 2.5.3 is a target, not a claim that
native Windows 2.5.3 validation has already passed.

## Preservation of original releases
All 36 original output files across v0.1 to v0.8 are preserved unchanged at:
https://drive.google.com/file/d/1tQBnUZ_vDF7tUTtiXf8WJC41OEXNVG_5/view

See Docs/Unified-Modhunter.md for the complete architecture and feature map.
