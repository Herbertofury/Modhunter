# ✧ Rewards and Integrity

## The two reward worlds

| Action | Game points | Official rewards |
|---|---:|---|
| Kill a named outdated-mod boss | **100 Hunt Points** in the run | Records a pending bounty when live/eligible; no Forge Sigils yet |
| Update that exact mod, verified by MO2 | **+200 ranked Chronicle points** bounty bonus | **+10 bonus Sigils** on top of the normal update award |
| Any verified version upgrade | Chronicle XP + combo | **10 Forge Sigils** |
| Repeat the same install/version | No new reward | **0** |
| Manual checklist click | Visual effects only | **0** |
| First Atlas mission clear | Progress + one *game-only Ember* | **0 Forge Sigils** |
| Practice/offline play | Separate practice progress | **0 official rewards** |

## Anti-farming rules

The MO2 Chronicle records a fingerprint for each real mod identity and destination version. Reinstalling an already rewarded version does not mint XP, and a pending boss bounty must match the exact original version and profile to qualify for its bonus.

The game UI cannot call the `record_update` function, fabricate MO2 version evidence, or write to native wallet balances. The local HTML and Electron app are not authoritative reward sources.

## Full-profile victory

A World-Eater ceremony requires a **fresh, completed full audit** proving all comparable Nexus-linked tracked mods are current. It does not claim to have verified local/generated mods or other unsupported providers.

## Safety controls

The plugin does not silently install, enable or move mods to grant a reward. Installation remains explicit and uses MO2's own installer after a pre-update profile text backup. Uncertain update comparisons remain review items.

[[MO2 Plugin]] · [[Compatibility and Safety]] · [[Unfinished Bestiary]]
