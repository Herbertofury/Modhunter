(()=>{if(window.__ARSENAL_REALM_ROUTE__)return;
'use strict';
let DATA=JSON.parse(document.getElementById('embeddedCatalog').textContent);
const MO2_EXPORTER=/*__POWERSHELL__*/;
let ITEM_MAP=new Map(DATA.items.map(m=>[m.id,m]));
let GROUP_MAP=new Map(DATA.groups.map(g=>[g.id,g]));
const PALETTE={gold:'#e2b975',stone:'#92959d',purple:'#b78cde',violet:'#a26cfa',mint:'#87d9bf',ochre:'#d5b77a',slate:'#8291af',sky:'#75b9d5',blue:'#6eabdc',green:'#86d58c',red:'#e16a6d',pink:'#df98b5',rose:'#e3b8c5',cyan:'#72d8e4',yellow:'#f2dc8b'};
let STORAGE='dragonborn-mod-update-arsenal-v1';
const BRIDGE=window.__MO2_BRIDGE_BOOT__||{active:false};
let LIVE_SCAN=null,LIVE_CATALOG=null,SCAN_TIMER=null,FILE_PICKER_MOD=null,LIVE_GENERATION=0,LIVE_REFRESH_BUSY=false;
let WORKSHOP_PLAN=null,WORKSHOP_CHOICES=new Map(),WORKSHOP_BUSY=false,WORKSHOP_REVIEW_ID=null;
let GAME=null,GAME_SEEN=-1,PROGRESS_READY=false,PROGRESS_TIMER=null,NATIVE_SELECTED='',VICTORY_ACTIVE=null,VICTORY_TIMERS=[],PRACTICE_CROWNED=false;
const BADGE_META=[['first-blood','First Blood','⚔',1],['apprentice','Apprentice Smith','🔨',5],['veteran','Veteran of the Forge','🛡',10],['archmage','Master Enchanter','✦',25],['dragonborn','Dragonborn','🐉',50],['legend','Legendary Smith','♛',100],['world-eater','World-Eater Defeated','👑',null]];

const BASE={rows:{},prefs:{filter:'all',query:'',sort:'priority',theme:'night',density:'compact',effect:'random',sound:false,focus:false,collapsed:[],vfxIntensity:'legendary',vfxShake:true,vfxTrails:true},lastSelected:null,verifiedRuntime:null};
let STORE=structuredClone(BASE),persistOK=true,focusedRowId='',lastUndo=null,openedId=null,toastTimer=null,activeFx=[],MO2_PENDING=[];
const $=(id)=>document.getElementById(id);
const txt=(v)=>String(v??'');
const escapeHTML=(v)=>txt(v).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const validUrl=(s)=>{try{const u=new URL(s);return ['https:','http:'].includes(u.protocol)?u.href:''}catch{return''}};
const getRow=(id)=>STORE.rows[id]||{};
const getStatus=(m)=>getRow(m.id).status||'pending';
const getAudit=(m)=>{const a=m.audit||{};return{verdict:getRow(m.id).compat||a.verdict||'unknown',note:a.note||'',evidence:a.evidence||''}};
const getSrc=(m)=>{const custom=validUrl(getRow(m.id).url),src=m.source||{};if(custom)return{url:custom,verified:true,custom:true,type:'custom',label:'Your link'};if(src.verified&&validUrl(src.url))return{url:src.url,verified:true,custom:false,type:src.type,label:src.label};const game=LIVE_CATALOG?.game||'skyrimspecialedition';return{url:'https://www.google.com/search?q='+encodeURIComponent((m.group==='Verified Creations'?'site:creations.bethesda.net/en/skyrim/details ':'site:nexusmods.com/'+game+'/mods/ ')+'"'+m.name+'"'),verified:false,custom:false,type:'lookup',label:'Unresolved search'}};
const isRisk=(m)=>{const {verdict}=getAudit(m);return ['hold','check','avoid','ae-only'].includes(verdict)||(m.flags||[]).some(f=>['HARD_ESP','HARD_ESM','DLL','NEMESIS'].includes(f))};
const isUpdate=(m)=>m.update&&m.update.verdict==='candidate';
const isDone=(m)=>getStatus(m)==='done';
const isReview=(m)=>getStatus(m)==='review';
const isFav=(m)=>Boolean(getRow(m.id).favorite);
const $all=(s,base=document)=>[...base.querySelectorAll(s)];
function load(){try{const x=JSON.parse(localStorage.getItem(STORAGE)||'null');if(x&&typeof x==='object'){
 for(const [id,raw] of Object.entries(x.rows||{})){if(ITEM_MAP.has(id)&&raw&&typeof raw==='object')STORE.rows[id]={...raw}}
 for(const k of Object.keys(BASE.prefs))if(x.prefs&&k in x.prefs)STORE.prefs[k]=x.prefs[k];
 STORE.lastSelected=x.lastSelected||null;STORE.verifiedRuntime=x.verifiedRuntime||null;
}}catch(e){persistOK=false;console.warn('Local save unavailable:',e)}
 if(!Array.isArray(STORE.prefs.collapsed))STORE.prefs.collapsed=[];
}
function save(){try{localStorage.setItem(STORAGE,JSON.stringify(STORE));persistOK=true}catch(e){persistOK=false;console.warn('Local storage failed:',e)}updateStorageIndicator();if(BRIDGE.active&&LIVE_CATALOG&&PROGRESS_READY)scheduleProgressSync()}
function scheduleProgressSync(){clearTimeout(PROGRESS_TIMER);const profile=LIVE_CATALOG?.profileId;if(!profile)return;const snapshot={profileId:profile,rows:structuredClone(STORE.rows),prefs:structuredClone(STORE.prefs),verifiedRuntime:STORE.verifiedRuntime};PROGRESS_TIMER=setTimeout(async()=>{if(LIVE_CATALOG?.profileId!==profile)return;try{await bridgeRequest('POST','progress',snapshot)}catch(ex){console.warn('MO2 Chronicle save:',ex.message);SET('liveState','Local save retained. MO2 Chronicle sync: '+ex.message)}},260)}
async function hydrateProgress(profile){try{const r=await bridgeRequest('GET','progress');if(!LIVE_CATALOG||LIVE_CATALOG.profileId!==profile||r.profileId!==profile)return;const stored=r.progress||{};
 if(stored.rows&&typeof stored.rows==='object'){for(const [id,row]of Object.entries(stored.rows)){if(ITEM_MAP.has(id)&&row&&typeof row==='object'){
  const local=getRow(id),incoming=Date.parse(row.updatedAt||0)||0,existing=Date.parse(local.updatedAt||0)||0;
  STORE.rows[id]=incoming>=existing?{...local,...row}:local;
 }}}
 if(stored.prefs&&typeof stored.prefs==='object'){for(const k of Object.keys(BASE.prefs))if(k in stored.prefs)STORE.prefs[k]=stored.prefs[k]}
 if(stored.verifiedRuntime)STORE.verifiedRuntime=stored.verifiedRuntime;
 // Server-origin progress still must be invalidated if the actual installed
 // version/runtime changed since the last save (including after MO2 restart).
 const currentRuntime=LIVE_CATALOG.gameRuntime||'unknown';
 if(STORE.verifiedRuntime&&STORE.verifiedRuntime!==currentRuntime){for(const row of Object.values(STORE.rows)){if(row.compat==='compatible'){delete row.compat;if(row.status==='done')row.status='review'}}}
 for(const mod of LIVE_CATALOG.items){const row=STORE.rows[mod.id];if(row?.status==='done'&&row.observedInstalledVersion&&row.observedInstalledVersion!==mod.installedVersion)row.status='review'}
 STORE.verifiedRuntime=currentRuntime;
 STORE.prefs.collapsed=Array.isArray(STORE.prefs.collapsed)?STORE.prefs.collapsed.filter(g=>GROUP_MAP.has(g)):[];
} catch(ex){console.warn('MO2 profile save unavailable, local fallback:',ex.message)}finally{if(LIVE_CATALOG?.profileId===profile){PROGRESS_READY=true;applyAppearance();$('search').value=STORE.prefs.query;render();save()}}}

function updateStorageIndicator(){const b=$('storageStatus');if(!b)return;b.textContent=persistOK?'◉ AUTO-SAVED LOCALLY':'⚠ SESSION ONLY · EXPORT JSON';b.style.color=persistOK?'var(--teal)':'var(--red)'}
function updatePrefs(p){STORE.prefs={...STORE.prefs,...p};save();applyAppearance();render()}
function applyAppearance(){document.body.dataset.theme=STORE.prefs.theme==='snow'?'snow':'night';document.body.dataset.density=STORE.prefs.density==='comfy'?'comfy':'compact';$('effectSelect').value=STORE.prefs.effect;$('soundToggle').textContent=STORE.prefs.sound?'♫':'♪̸';$('soundToggle').title=STORE.prefs.sound?'Mute sounds':'Enable sounds';$('soundToggle').setAttribute('aria-label',STORE.prefs.sound?'Effect sounds on':'Effect sounds off');$('themeToggle').textContent=STORE.prefs.theme==='snow'?'☾':'◐';document.body.dataset.focus=STORE.prefs.focus?'yes':'no';$('focusToggle').textContent=STORE.prefs.focus?'◉ Exit Focus':'◎ Focus';$('focusToggle').setAttribute('aria-pressed',String(Boolean(STORE.prefs.focus)));$('focusTop').textContent=STORE.prefs.focus?'◉':'▦';$('focusTop').setAttribute('aria-pressed',String(Boolean(STORE.prefs.focus)));$('fxIntensity').value=STORE.prefs.vfxIntensity||'legendary';$('fxShake').checked=STORE.prefs.vfxShake!==false;$('fxTrails').checked=STORE.prefs.vfxTrails!==false;window.AetherFX?.config({intensity:STORE.prefs.vfxIntensity||'legendary',shake:STORE.prefs.vfxShake!==false,trails:STORE.prefs.vfxTrails!==false,sound:STORE.prefs.sound})}
function counts(){const total=DATA.items.length,done=DATA.items.filter(isDone).length,review=DATA.items.filter(isReview).length,risky=DATA.items.filter(isRisk).length,unlinked=DATA.items.filter(m=>!getSrc(m).verified).length,favorites=DATA.items.filter(isFav).length,pending=DATA.items.filter(m=>getStatus(m)==='pending').length;return{total,done,review,risky,unlinked,favorites,pending,updates:DATA.items.filter(isUpdate).length,left:total-done,percent:total?Math.round(done/total*100):0}}
const SET=(id,val)=>{const el=$(id);if(el)el.textContent=val};
function renderStats(){const c=counts();SET('sidePercent',c.percent+'%');$('sideProgressFill').style.width=c.percent+'%';SET('sideDone',c.done);SET('sideRemaining',c.left);SET('sideDanger',c.risky);SET('heroPercent',c.percent+'%');SET('heroProgressLabel',`${c.done} / ${c.total} mods`);$('heroMotivation').textContent=c.percent===100?'SOVNGARDE IS YOURS':c.percent>=75?'THE FINAL ASSAULT':c.percent>=40?'THE TIDE TURNS':'THE JOURNEY BEGINS';document.querySelector('.orb-outer').style.setProperty('--percent',c.percent+'%');SET('metricTotal',c.total);SET('metricSections',DATA.groups.length+' hand-sorted sections');SET('metricDone',c.done);SET('metricRemaining',c.left+' left in the quest');SET('metricWatch',c.risky);SET('metricLinks',c.total-c.unlinked);SET('metricLinksSub',c.unlinked+' still need source confirmation');
 for(const [k,v] of Object.entries({All:c.total,Pending:c.pending,Done:c.done,Review:c.review,Risk:c.risky,Unlinked:c.unlinked,Favorite:c.favorites,Updates:c.updates}))SET('nav'+k+'Count',v);
 $all('[data-filter]').forEach(el=>{const on=el.dataset.filter===STORE.prefs.filter;el.classList.toggle('active',on);if(el.tagName==='BUTTON')el.setAttribute('aria-pressed',String(on))});
}
function tokenizeQuery(raw){const out=[];const re=/"([^"]+)"|(\S+)/g;let m;while((m=re.exec(raw)))out.push((m[1]||m[2]).trim().toLowerCase());return out}
function textMatches(m,query){if(!query)return true;const str=[m.name,m.installedVersion,m.screenshotNote,m.author,m.group,m.priority,m.flags.join(' '),getRow(m.id).note,getRow(m.id).installed].join(' ').toLowerCase();return tokenizeQuery(query).every(part=>{const ix=part.indexOf(':');if(ix>0){const p=part.slice(0,ix),v=part.slice(ix+1);if(p==='author')return m.author.toLowerCase().includes(v);if(p==='section'||p==='group')return m.group.toLowerCase().includes(v);if(p==='flag')return m.flags.join(' ').toLowerCase().includes(v);if(p==='priority')return txt(m.priority).includes(v);if(p==='status')return getStatus(m).includes(v);if(p==='version')return m.installedVersion.toLowerCase().includes(v);if(p==='note')return (m.screenshotNote+' '+txt(getRow(m.id).note)).toLowerCase().includes(v);}return str.includes(part)})}
function filtered(){const f=STORE.prefs.filter;return DATA.items.filter(m=>textMatches(m,STORE.prefs.query)&&(
 f==='all'||(f==='pending'&&getStatus(m)==='pending')||(f==='done'&&isDone(m))||(f==='review'&&isReview(m))||(f==='risky'&&isRisk(m))||(f==='unlinked'&&!getSrc(m).verified)||(f==='favorites'&&isFav(m))||(f==='updates'&&isUpdate(m))));}
function classFor(m){const s=getStatus(m);return s==='done'?'done':s==='review'?'needs-review':s==='skipped'?'skipped':''}
function assessmentHTML(m){const audit=getAudit(m),out=[];
 const map={'safe-file':['✓ SE FILE','safe-file'],hold:['⚠ HOLD','hold'],avoid:['⛔ AE ONLY','avoid'],check:['? VERIFY','check'],compatible:['✓ COMPATIBLE','compatible'],'ae-only':['⛔ AE ONLY','ae-only']};
 if(map[audit.verdict])out.push(`<span class="tag ${map[audit.verdict][1]}" title="${escapeHTML(audit.note||audit.verdict)}">${map[audit.verdict][0]}</span>`);
 if(m.flags.includes('HARD_ESP')||m.flags.includes('HARD_ESM'))out.push(`<span class="tag hard" title="Master/plugin caution; verify masters and load order">HARD ${m.flags.includes('HARD_ESM')?'ESM':'ESP'}</span>`);
 if(m.flags.includes('ESL'))out.push('<span class="tag esl" title="Light plugin / ESL as annotated in screenshot">ESL</span>');
 if(m.flags.includes('DLL')&&!map[audit.verdict])out.push('<span class="tag dll" title="SKSE DLL: verify game/runtime build">DLL CHECK</span>');
 if(m.flags.includes('NEMESIS'))out.push('<span class="tag check" title="Rerun Nemesis / animation behavior generator if affected">NEMESIS</span>');
 if(m.update&&m.update.verdict==='candidate')out.unshift('<span class="tag safe-file" title="Nexus indicates a newer version; verify runtime and file choice">ϟ UPDATE</span>');
 if(m.update&&m.update.verdict==='review')out.unshift('<span class="tag check" title="Version ordering ambiguous; review original files">? REVIEW VERSION</span>');
 if(m.update&&m.update.verdict==='current')out.unshift('<span class="tag compatible">✓ CURRENT</span>');
 if(m.update&&m.update.verdict==='newer-installed')out.unshift('<span class="tag compatible">✓ AHEAD OF SOURCE</span>');
 if(!out.length)out.push('<span class="tag unknown" title="No file-specific compatibility proof yet">NOT VERIFIED</span>');return out.join('');}
function modHTML(m){const s=getSrc(m),sourceText=s.type==='creations'?'↗ Creation':s.verified?'↗ Files':'⌕ Find page',note=getRow(m.id).note||m.screenshotNote||'',stat=getStatus(m),statusLabel=stat==='done'?'Clear completed status':stat==='review'?'Mark mod cleared':'Mark mod cleared';
 return `<article class="mod-row ${classFor(m)}" id="row-${escapeHTML(m.id)}" data-id="${escapeHTML(m.id)}">
 <div class="mod-status"><button class="complete-btn" data-act="complete" data-id="${m.id}" aria-label="${escapeHTML(statusLabel+' for '+m.name)}" title="${escapeHTML(statusLabel)}">${stat==='done'?'✓':stat==='review'?'!':''}</button></div>
 <div class="mod-priority">${m.priority}</div>
 <div class="mod-primary" data-priority="${m.priority}">${BRIDGE.active?`<button class="mod-title locate-title" type="button" title="Select and scroll to this exact mod in MO2" data-act="locate" data-id="${escapeHTML(m.id)}"><span class="locate-crosshair">⌖</span> ${escapeHTML(m.name)}</button>`:`<a class="mod-title ${s.verified?'':'unknown'}" href="${escapeHTML(s.url)}" target="_blank" rel="noopener noreferrer" title="${escapeHTML(s.verified?'Open exact mod source':'Find mod source')}" data-act="source" data-id="${m.id}">${escapeHTML(m.name)}</a>`}${note?`<div class="mod-note ${/do not|ctd|crash|hard esp|incompati|needs update|bugs/i.test(note)?'warning-note':''}" title="${escapeHTML(note)}">${escapeHTML(note)}</div>`:''}</div>
 <div class="mod-version" title="Installed version recorded by source">${escapeHTML(getRow(m.id).installed||m.installedVersion)}${m.update?.latestVersion?`<small class="newer-version" title="Latest metadata, not necessarily compatible">→ ${escapeHTML(m.update.latestVersion)}</small>`:''}</div>
 <div class="mod-assessment">${assessmentHTML(m)}</div>
 <div class="mod-source"><a class="source-btn ${s.verified?'':'lookup'}" href="${escapeHTML(s.url)}" target="_blank" rel="noopener noreferrer" data-act="source" data-id="${m.id}" title="${escapeHTML(s.type==='creations'?'Exact Bethesda Creation listing. Install from in-game Creations menu.':s.verified?'Exact mod files page':'Search for the correct mod project; source not yet verified')}">${sourceText}</a></div>
 <div class="inspect-col">${BRIDGE.active&&m.nexusId?`<button class="file-download-btn" title="Choose an exact Nexus file in MO2" aria-label="Choose Nexus files for ${escapeHTML(m.name)}" data-act="files" data-id="${m.id}">⇩</button>`:''}<button class="favorite-btn ${isFav(m)?'active':''}" title="${isFav(m)?'Remove bookmark':'Bookmark mod'}" aria-label="Bookmark ${escapeHTML(m.name)}" data-act="favorite" data-id="${m.id}">${isFav(m)?'★':'☆'}</button><button class="inspect-btn" title="Inspect mod, notes, compatibility and source" aria-label="Inspect ${escapeHTML(m.name)}" data-act="inspect" data-id="${m.id}">⋯</button></div>
 </article>`}
let GROUP_PROGRESS=new Map();function groupProgress(){GROUP_PROGRESS=new Map(DATA.groups.map(g=>[g.id,{done:0,total:0}]));for(const m of DATA.items){if(!GROUP_PROGRESS.has(m.groupId))GROUP_PROGRESS.set(m.groupId,{done:0,total:0});const o=GROUP_PROGRESS.get(m.groupId);o.total++;if(isDone(m))o.done++}}
function renderChapters(){let needle=$('chapterSearch').value.trim().toLowerCase();const html=DATA.groups.filter(g=>!needle||g.name.toLowerCase().includes(needle)).map(g=>{const num=GROUP_PROGRESS.get(g.id)?.done||0;return `<button class="chapter-link" style="--group-clr:${PALETTE[g.color]||PALETTE.slate}" data-chapter="${g.id}" title="Jump to ${escapeHTML(g.name)}"><i></i><span>${escapeHTML(g.name)}</span><em>${num}/${g.count}</em></button>`}).join('');$('chapters').innerHTML=html||'<div class="drawer-micro" style="padding:12px">No chapter found.</div>'}
function renderList(){const visible=filtered(),byGroup=new Map();for(const m of visible){if(!byGroup.has(m.groupId))byGroup.set(m.groupId,[]);byGroup.get(m.groupId).push(m)}
 let html='';for(const g of DATA.groups){const ms=byGroup.get(g.id);if(!ms||!ms.length)continue;let sorted=[...ms];if(STORE.prefs.sort==='name')sorted.sort((a,b)=>a.name.localeCompare(b.name));else if(STORE.prefs.sort==='version')sorted.sort((a,b)=>a.installedVersion.localeCompare(b.installedVersion));else sorted.sort((a,b)=>a.priority-b.priority);
 const gd=GROUP_PROGRESS.get(g.id)?.done||0;const collapsed=STORE.prefs.collapsed.includes(g.id),pct=Math.round((gd/(g.count||1))*100);
 html+=`<button class="chapterbar ${collapsed?'closed':''}" id="section-${g.id}" data-chapter-toggle="${g.id}" style="--chapter-color:${PALETTE[g.color]||PALETTE.slate}" aria-expanded="${!collapsed}"><span class="diamond">◆</span><strong>${escapeHTML(g.name)}</strong><span class="chapter-count">${gd}/${g.count}</span><span class="chapter-mini-progress"><i style="width:${pct}%"></i></span><span class="chapter-priority">#${g.startPriority}</span></button>`;
 if(!collapsed)html+=sorted.map(modHTML).join('');}
 $('modList').innerHTML=html||`<div class="empty-state"><div class="empty-icon">ᛟ</div><h3>No foes in this chamber.</h3><p>Nothing matches your current search and filters.</p><button id="emptyReset">Clear filters</button></div>`;
 const parts=[visible.length+' of '+DATA.items.length+' mods',byGroup.size+' chapters'];if(STORE.prefs.query)parts.push('query: '+STORE.prefs.query);SET('resultsMeta',parts.join(' · '));SET('listFooter',`YOU'VE REACHED THE END · ${visible.length} MATCHING MODS · ${counts().total-counts().unlinked} EXACT ORIGINAL SOURCES`);$('sortSelect').value=STORE.prefs.sort;}
function render(){groupProgress();renderStats();renderList();renderChapters();renderQuest();paintNativeSelection();renderWorkshop()}
function setStatus(m,status,withEffect=false,center){if(!['pending','done','review','skipped'].includes(status))return;const old=getStatus(m);if(old===status)return;const previousRow=$('row-'+m.id);const effectMode=STORE.prefs.effect==='random'?['shatter','fireworks','shot','slash','burn','arrow','frost','thunder'][Math.floor(Math.random()*8)]:STORE.prefs.effect;if(withEffect&&status==='done')window.AetherFX?.complete(previousRow,{mode:effectMode});else if(withEffect&&status==='pending')window.AetherFX?.undo(previousRow);getRow(m.id).status=old;STORE.rows[m.id]={...getRow(m.id),status,observedInstalledVersion:status==='done'?m.installedVersion:null,updatedAt:new Date().toISOString()};lastUndo={id:m.id,previous:old,next:status};save();render();if(withEffect&&status==='done')spawnFinisher(center||centerOfRow(m.id),effectMode);toast(status==='done'?'✦ '+m.name+' — quest cleared!'+(BRIDGE.active?' (manual, no ranked XP)':''):'Updated '+m.name,()=>undoLast(),'UNDO');if(!BRIDGE.active&&counts().total>0&&counts().done===counts().total&&!PRACTICE_CROWNED){PRACTICE_CROWNED=true;setTimeout(()=>launchVictory({verifiedMods:DATA.items.length,bonus:0,updates:DATA.items.length},true),420)}}
function undoLast(){if(!lastUndo)return;const action=lastUndo;lastUndo=null;window.AetherFX?.undo($('row-'+action.id));STORE.rows[action.id]={...getRow(action.id),status:action.previous};save();render();toast('↶ Last change undone.');}
function centerOfRow(id){const el=$('row-'+id);if(!el)return{x:window.innerWidth*.5,y:window.innerHeight*.45};const r=el.getBoundingClientRect();return{x:Math.max(20,r.left+Math.min(r.width*.42,420)),y:r.top+r.height*.5}}
function toggleDone(id,el){const m=ITEM_MAP.get(id);if(!m)return;const r=el?.closest('.mod-row')?.getBoundingClientRect();const pos=r?{x:r.left+Math.min(r.width*.44,450),y:r.top+r.height*.5}:centerOfRow(id);setStatus(m,isDone(m)?'pending':'done',true,pos);}
function toast(message,action,actionLabel){const w=$('toastWrap');const el=document.createElement('div');el.className='toast';el.innerHTML=`<span>${escapeHTML(message)}</span>`;if(action){const b=document.createElement('button');b.textContent=actionLabel||'UNDO';b.addEventListener('click',()=>{action();el.remove()});el.append(b)}w.append(el);while(w.children.length>3)w.firstChild.remove();setTimeout(()=>{el.style.opacity='0';el.style.transition='opacity .2s';setTimeout(()=>el.remove(),220)},3600)}
function nextPending(){const filteredPending=DATA.items.filter(m=>getStatus(m)==='pending');if(!filteredPending.length){toast('Everything is cleared or marked for review. Skyrim belongs to you.');return}let target=filteredPending.find(m=>m.priority>Number((ITEM_MAP.get(focusedRowId)||{}).priority||0))||filteredPending[0];STORE.prefs.filter='all';STORE.prefs.query='';$('search').value='';if(STORE.prefs.collapsed.includes(target.groupId))STORE.prefs.collapsed=STORE.prefs.collapsed.filter(g=>g!==target.groupId);save();render();focusRow(target.id);}
function focusRow(id){const row=$('row-'+id);if(!row)return;focusedRowId=id;row.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'center'});row.classList.remove('focus-signal');void row.offsetWidth;row.classList.add('focus-signal');window.AetherFX?.select(row,{source:'app'});const b=row.querySelector('[data-act="complete"]');if(b)b.focus({preventScroll:true});}
function jumpChapter(id){STORE.prefs.filter='all';STORE.prefs.query='';$('search').value='';if(STORE.prefs.collapsed.includes(id))STORE.prefs.collapsed=STORE.prefs.collapsed.filter(x=>x!==id);save();render();const el=$('section-'+id);el?.scrollIntoView({behavior:'smooth',block:'start'});$('sidebar').classList.remove('open')}
function resetFilters(){STORE.prefs.filter='all';STORE.prefs.query='';$('search').value='';save();render()}
function toggleAllChapters(){const allClosed=STORE.prefs.collapsed.length===DATA.groups.length;STORE.prefs.collapsed=allClosed?[]:DATA.groups.map(g=>g.id);$('collapseAll').textContent=allClosed?'Collapse':'Expand';save();render();}
function drawInspector(m){openedId=m.id;STORE.lastSelected=m.id;save();const row=getRow(m.id),audit=getAudit(m),source=getSrc(m);SET('drawerTitle',m.name);
 const selected=(v)=>row.compat===v?'selected':'';const status=getStatus(m);
 $('drawerContent').innerHTML=`<div class="drawer-priority"><span>MO2 PRIORITY #${m.priority}</span><span>${escapeHTML(m.group)}</span><span>${BRIDGE.active?'LIVE PROFILE':'SCREENSHOT '+m.screenshot}</span></div>
 <div class="drawer-section drawer-alert" data-alert="${escapeHTML(audit.verdict)}"><span class="drawer-label" style="margin:0">${BRIDGE.active?'RUNTIME / FILE COMPATIBILITY CHECK':'1.5.97 COMPATIBILITY ADVISORY'}</span><strong>${escapeHTML(audit.verdict==='avoid'?'AVOID LATEST RELEASE':audit.verdict==='hold'?'HOLD / PICK LEGACY FILE':audit.verdict==='safe-file'?'SE BUILD LISTED':audit.verdict==='check'?'VERIFY SPECIFIC BUILD':'NOT YET VERIFIED')}</strong><p>${escapeHTML(audit.note||'The provided screenshots do not establish compatibility for a new release. Check the required game executable, SKSE, Address Library, BEES and masters before updating.')}</p>${audit.evidence?`<a class="drawer-link" href="${escapeHTML(audit.evidence)}" target="_blank" rel="noopener noreferrer">↗ View supporting source</a>`:''}</div>
 <label class="drawer-label" for="drawerStatus">CHECKLIST STATUS</label><select class="drawer-field" id="drawerStatus"><option value="pending" ${status==='pending'?'selected':''}>◷ Not checked</option><option value="done" ${status==='done'?'selected':''}>✓ Updated / cleared</option><option value="review" ${status==='review'?'selected':''}>⚠ Needs investigation</option><option value="skipped" ${status==='skipped'?'selected':''}>⤼ Deliberately skipped</option></select>
 <div class="drawer-row"><div><label class="drawer-label" for="drawerInstalled">INSTALLED VERSION</label><input class="drawer-field" id="drawerInstalled" value="${escapeHTML(row.installed||m.installedVersion)}" placeholder="version"></div><div><label class="drawer-label" for="drawerVerifiedVersion">FILE YOU TESTED</label><input class="drawer-field" id="drawerVerifiedVersion" value="${escapeHTML(row.testedVersion||'')}" placeholder="e.g. SE 1.5.97 FOMOD"></div></div>
 <label class="drawer-label" for="drawerCompat">YOUR COMPATIBILITY VERDICT</label><select class="drawer-field" id="drawerCompat"><option value="" ${!row.compat?'selected':''}>Use evidence / unverified</option><option value="compatible" ${selected('compatible')}>✓ Verified working on ${BRIDGE.active?escapeHTML(DATA.gameRuntime||'this runtime'):'1.5.97'}</option><option value="check" ${selected('check')}>? Must check specific file</option><option value="hold" ${selected('hold')}>⚠ Hold pinned version</option><option value="ae-only" ${selected('ae-only')}>⛔ AE-only or 1.7+ build</option></select>
 <label class="drawer-label" for="drawerUrl">EXACT MOD FILE DOWNLOAD PAGE</label><input class="drawer-field" id="drawerUrl" type="url" spellcheck="false" value="${escapeHTML(row.url||m.source.url||'')}" placeholder="https://www.nexusmods.com/skyrimspecialedition/mods/12345?tab=files"><div class="drawer-micro">${source.type==='creations'?'✓ Official Bethesda listing; downloads/installations are handled through in-game Creations.':source.verified?'✓ This mod has an exact source page.':'⚠ No verified original source ID yet. Use the lookup link and paste its exact Files page.'}</div>
 <div class="drawer-section" style="margin-top:10px">${BRIDGE.active?`<button class="button-bright drawer-m2-focus" id="drawerLocate" type="button" title="Reveal this exact mod in Mod Organizer 2">⌖ REVEAL IN MO2 · SELECT + SCROLL</button>`:''}<a class="drawer-link" id="drawerOpenLink" href="${escapeHTML(source.url)}" target="_blank" rel="noopener noreferrer">↗ ${source.type==='creations'?'OPEN OFFICIAL CREATION LISTING':source.verified?'OPEN EXACT FILE DOWNLOAD PAGE':'FIND ORIGINAL MOD PAGE (UNVERIFIED)'}</a><button class="quiet-button" style="height:29px;margin-top:7px" id="copySource">⧉ Copy source URL</button></div>
 <label class="drawer-label" for="drawerNote">YOUR UPDATE NOTES / TEST RESULTS</label><textarea class="drawer-field" id="drawerNote" placeholder="Selections, dependencies, before/after, crashes, load order conflicts…">${escapeHTML(row.note||'')}</textarea>
 ${m.screenshotNote?`<div class="drawer-section"><span class="drawer-label" style="margin:0">ORIGINAL SCREENSHOT NOTES</span><p>${escapeHTML(m.screenshotNote)}</p></div>`:''}
 <div class="drawer-check"><input type="checkbox" id="drawerFavorite" ${row.favorite?'checked':''}><label for="drawerFavorite">Bookmark this mod in the sidebar</label></div>
 <div class="drawer-action-bar"><button id="saveInspector">✦ Save inspection</button><button id="markInspectorDone">✓ Mark cleared</button></div>
 <p class="drawer-micro" style="margin-top:15px">${BRIDGE.active?'Your notes and verdicts are persisted in the MO2 Chronicle for this profile. Manual clearing does not award ranked XP.':'Your notes and verdicts are local to this browser. Back up JSON before moving machines.'} This dashboard does not directly modify installed mod files.</p>`;
 $('drawerVeil').hidden=false;$('detailDrawer').classList.add('open');$('detailDrawer').setAttribute('aria-hidden','false');setTimeout(()=>$('drawerStatus').focus(),130);
 $('copySource').onclick=()=>copyToClipboard(getSrc(m).url);if(BRIDGE.active&&$('drawerLocate'))$('drawerLocate').onclick=()=>locateInMO2(m,$('drawerLocate'));
 $('saveInspector').onclick=()=>saveInspection(false);
 $('markInspectorDone').onclick=()=>saveInspection(true);
}
function saveInspection(forceDone){const m=ITEM_MAP.get(openedId);if(!m)return;const url=$('drawerUrl').value.trim();if(url&&!validUrl(url)){toast('Please enter a valid http(s) mod URL.');$('drawerUrl').focus();return}
 const old=getStatus(m);const selected=$('drawerStatus').value;const next=forceDone?'done':selected;
 STORE.rows[m.id]={...getRow(m.id),status:next,installed:$('drawerInstalled').value.trim(),testedVersion:$('drawerVerifiedVersion').value.trim(),compat:$('drawerCompat').value,url:url,note:$('drawerNote').value,favorite:$('drawerFavorite').checked,updatedAt:new Date().toISOString()};save();closeInspector();render();if(next==='done'&&old!=='done')spawnFinisher(centerOfRow(m.id));toast('✦ Inspection recorded for '+m.name);}
function closeInspector(){$('drawerVeil').hidden=true;$('detailDrawer').classList.remove('open');$('detailDrawer').setAttribute('aria-hidden','true');openedId=null}
function help(open){$('helpVeil').hidden=!open;}
async function copyToClipboard(value){try{await navigator.clipboard.writeText(value);toast('⧉ Source URL copied.')}catch{const t=document.createElement('textarea');t.value=value;document.body.append(t);t.select();let success=false;try{success=document.execCommand('copy')}catch{}t.remove();toast(success?'Source URL copied.':'Copy unavailable. Select the URL in the inspector.')}}
function exportJSON(){const obj={format:'Mod Update Arsenal Backup',version:1,createdAt:new Date().toISOString(),catalogId:DATA.catalogId,sourceRevision:DATA.sourceRevision,items:DATA.items.length,rows:STORE.rows,prefs:STORE.prefs,lastSelected:STORE.lastSelected,verifiedRuntime:STORE.verifiedRuntime};saveFile((BRIDGE.active?'MO2 Update Arsenal - '+(LIVE_CATALOG?.profileName||'Profile')+' - Progress.json':'Skyrim 1.5.97 - Mod Update Progress.json'),'application/json',JSON.stringify(obj,null,2));toast('↓ Full progress backup saved.');}
function saveFile(name,type,body){const blob=new Blob([body],{type:type+';charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3500)}
function csvCell(v){return'"'+txt(v).replace(/"/g,'""')+'"'}
function exportCSV(){const cols=['Priority','Mod','Section','Installed version','Status','1.5.97 Verdict','Type Flags','Exact Source URL','Source Verified','Source Provider','Screenshot Note','User Note','Tested Version','Author'];const csv=[cols.map(csvCell).join(',')];for(const m of filtered()){const r=getRow(m.id),s=getSrc(m);const c=[m.priority,m.name,m.group,r.installed||m.installedVersion,getStatus(m),getAudit(m).verdict,m.flags.join(';'),s.verified?s.url:'',s.verified?'yes':'NO',s.label,m.screenshotNote,r.note||'',r.testedVersion||'',m.author];csv.push(c.map(csvCell).join(','))}saveFile((BRIDGE.active?'MO2 Update Arsenal - Visible Mods.csv':'Skyrim 1.5.97 - Visible Mod Checklist.csv'),'text/csv','\ufeff'+csv.join('\r\n'));toast('⇩ CSV exported for '+filtered().length+' visible mods.');}
async function importJSON(file){if(!file)return;try{const obj=JSON.parse(await file.text());if(obj.catalogId!==DATA.catalogId||!obj.rows||typeof obj.rows!=='object')throw Error('This is not an Update Arsenal progress backup for the current catalog.');const imported=Object.entries(obj.rows).filter(([id])=>ITEM_MAP.has(id));if(!confirm('Restore '+imported.length+' saved mod records? This merges records from the backup into this browser.'))return;for(const[id,v]of imported)if(v&&typeof v==='object')STORE.rows[id]={...STORE.rows[id],...v};if(obj.prefs&&typeof obj.prefs==='object'){const allowed=Object.keys(BASE.prefs);for(const k of allowed)if(k in obj.prefs)STORE.prefs[k]=obj.prefs[k]}save();$('search').value=STORE.prefs.query;applyAppearance();render();toast('✓ Restored '+imported.length+' saved mod records.')}catch(e){toast('⚠ Restore failed: '+e.message)}finally{$('importFile').value=''}}
// The optional PowerShell bridge is embedded as text, downloaded on demand and never executed by the browser.
function mo2Open(){ $('mo2Veil').hidden=false; if(MO2_PENDING.length)drawMO2Matcher();else $('mo2Results').textContent=''; }
function mo2Close(){ $('mo2Veil').hidden=true; }
const mo2Key=(str)=>txt(str).normalize('NFKC').toLowerCase().replace(/[‐‑–—]/g,'-').replace(/[^\p{L}\p{N}]+/gu,' ').trim().replace(/\s+/g,' ');
const mo2Link=(id)=>'https://www.nexusmods.com/skyrimspecialedition/mods/'+id+'?tab=files';
const mo2ValidId=(id)=>/^[1-9]\d{0,9}$/.test(txt(id).trim());
function mo2ApplyLink(m,input){const id=txt(input.modId).trim();if(!mo2ValidId(id))return false;const prev=getRow(m.id);if(prev.url||m.source.verified)return false;
 const files=Array.isArray(input.fileIds)?input.fileIds.filter(x=>mo2ValidId(x)).slice(0,25):[];
 STORE.rows[m.id]={...prev,url:mo2Link(id),mo2Source:true,mo2FileIds:files,mo2FolderName:input.name};return true;
}
function drawMO2Matcher(){const panel=$('mo2Resolver');panel.hidden=!MO2_PENDING.length;if(panel.hidden)return;
 const q=mo2Key($('mo2Lookup').value);$('mo2PendingCount').textContent=MO2_PENDING.length+' folder'+(MO2_PENDING.length===1?'':'s')+' need review';
 const sources=q?MO2_PENDING.filter(x=>mo2Key(x.name).includes(q)):[];
 const from=$('mo2From'),oldFrom=from.value;from.replaceChildren();
 const add=(sel,val,label)=>{const opt=new Option(label,val);sel.add(opt)};
 if(!q)add(from,'','Search above to choose a folder');
 else if(!sources.length)add(from,'','No matching imported folders');
 else for(const input of sources)add(from,input._key,input.name+'  →  Nexus #'+input.modId);
 if(sources.some(x=>x._key===oldFrom))from.value=oldFrom;
 const target=$('mo2To'),oldTarget=target.value;target.replaceChildren();
 const unresolved=DATA.items.filter(x=>!getSrc(x).verified);
 if(!unresolved.length)add(target,'','Every visible mod now has a link');
 else for(const m of unresolved)add(target,m.id,'#'+m.priority+'  '+m.name);
 if(unresolved.some(x=>x.id===oldTarget))target.value=oldTarget;
 mo2UpdatePreview();
}
function mo2UpdatePreview(){const entry=MO2_PENDING.find(x=>x._key===$('mo2From').value),m=ITEM_MAP.get($('mo2To').value);
 const okay=!!entry&&!!m&&!getSrc(m).verified;
 $('mo2Bind').disabled=!okay;
 $('mo2MatchPreview').textContent=okay?`MO2: ${entry.name} • Nexus #${entry.modId}  →  ${m.name} • priority ${m.priority} • installed ${m.installedVersion||'unknown'} • ${m.group}`:'Type a folder name, then choose the matching checklist mod before binding.';
}
async function importMO2(file){if(!file)return;try{
 const data=JSON.parse(await file.text());
 if(data.format!=='MO2 Mod Update Arsenal Sources'||!Array.isArray(data.mods))throw Error('Wrong JSON. Choose the file created by the MO2 Source Exporter, not a progress backup.');
 const names=new Map();for(const m of DATA.items){const k=mo2Key(m.name);if(!names.has(k))names.set(k,[]);names.get(k).push(m)}
 let linked=0,present=0,unmatched=0,missingId=0,ambiguous=0;
 MO2_PENDING=[];
 for(const input of data.mods){if(!input||typeof input.name!=='string')continue;
  const found=names.get(mo2Key(input.name))||[];
  const id=txt(input.modId).trim();
  if(!found.length){unmatched++;if(mo2ValidId(id))MO2_PENDING.push({...input,_key:'folder-'+MO2_PENDING.length,modId:id});continue}
  if(found.length!==1){ambiguous++;continue}
  if(!mo2ValidId(id)){missingId++;continue}
  const m=found[0];if(getRow(m.id).url||m.source.verified){present++;continue}
  if(mo2ApplyLink(m,input))linked++;
 }
 save();render();$('mo2Lookup').value='';drawMO2Matcher();
 const report=`✦ ${linked} newly linked · ${present} already linked · ${unmatched} unmatched names · ${missingId} missing IDs · ${ambiguous} ambiguous matches`;
 $('mo2Results').textContent=report;
 toast('⌁ Linked '+linked+' mod pages from your MO2 data.');
}catch(e){$('mo2Results').textContent='⚠ '+e.message;toast('⚠ MO2 import failed: '+e.message)}finally{$('mo2File').value=''}}
function bindMO2Match(){const entry=MO2_PENDING.find(x=>x._key===$('mo2From').value),m=ITEM_MAP.get($('mo2To').value);if(!entry||!m)return;
 if(!mo2ApplyLink(m,entry)){toast('That mod already has a link. No changes made.');return}
 MO2_PENDING=MO2_PENDING.filter(x=>x!==entry);save();render();drawMO2Matcher();
 $('mo2Results').textContent=`✦ Linked ${m.name} to Nexus #${entry.modId} from your MO2 folder “${entry.name}”.`;
 toast('✦ Matched '+m.name+'!');
}
function drawCombatFinisher(mode,{x,y}){
 const layer=$('impactLayer'),d=document.createElement('div');d.className='combat-composition '+mode;d.style.left=x+'px';d.style.top=y+'px';d.style.setProperty('--spin',(Math.random()>.5?'1':'-1'));layer.append(d);setTimeout(()=>d.remove(),1300);
 const svg=(markup)=>{const el=document.createElementNS('http://www.w3.org/2000/svg','svg');el.setAttribute('viewBox','0 0 300 220');el.setAttribute('class','combat-svg');el.innerHTML=markup;d.append(el)};
 if(mode==='slash'){
  svg('<path class="sword-core" d="M10 195 Q120 80 285 11"/><path class="sword-echo" d="M11 204 Q128 104 288 28"/><path class="sword-cut" d="M255 17 Q143 95 22 199"/>');
  for(let i=0;i<12;i++){const p=document.createElement('i');p.className='slash-spark';p.style.setProperty('--a',(i*30)+'deg');p.style.setProperty('--travel',(32+Math.random()*105)+'px');d.append(p)}
 } else if(mode==='burn'){
  for(let i=0;i<20;i++){let p=document.createElement('i');p.className='fire-tongue';p.style.setProperty('--dx',(Math.random()*150-75)+'px');p.style.setProperty('--dy',(-Math.random()*165-25)+'px');p.style.setProperty('--delay',(Math.random()*180)+'ms');p.style.setProperty('--scale',(.5+Math.random()*1.7));d.append(p)}
  svg('<path class="fire-ring" d="M4 111 Q150 -25 296 111 Q150 250 4 111Z"/>');
 } else if(mode==='arrow'){
  svg('<path class="arrow-trail" d="M0 219 L152 109"/><path class="arrow-shaft" d="M4 205 L155 107"/><path class="arrow-head" d="M130 112 L169 99 L151 138"/><circle class="arrow-target" cx="157" cy="108" r="38"/>');
 } else if(mode==='frost'){
  svg('<circle class="ice-ring" cx="150" cy="110" r="34"/><circle class="ice-ring second" cx="150" cy="110" r="60"/>');
  for(let i=0;i<18;i++){let el=document.createElement('i');el.className='ice-crystal';el.style.setProperty('--a',(i*20)+'deg');el.style.setProperty('--distance',(45+Math.random()*90)+'px');d.append(el)}
 } else if(mode==='thunder'){
  const pts='156,-50 139,35 170,35 115,118 150,112 132,215';svg(`<polyline class="thunder-glow" points="${pts}"/><polyline class="thunder-core" points="${pts}"/><circle class="thunder-burst" cx="132" cy="213" r="14"/>`);
 } else if(mode==='shatter'){
  const lines=Array.from({length:13},(_,i)=>{const a=i*Math.PI*2/13;const x1=150+Math.cos(a)*19,y1=110+Math.sin(a)*19,x2=150+Math.cos(a)*115,y2=110+Math.sin(a)*105;return`<path class="crack-line" d="M ${x1} ${y1} L ${150+Math.cos(a+.12)*54} ${110+Math.sin(a+.12)*55} L ${x2} ${y2}"/>`}).join('');svg('<circle class="glass-impact" cx="150" cy="110" r="22"/>'+lines);
 }
}
function playClick(){if(!STORE.prefs.sound)return;try{const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;const ctx=new Audio();const oscillator=ctx.createOscillator(),gain=ctx.createGain();oscillator.type='triangle';oscillator.frequency.setValueAtTime(490,ctx.currentTime);oscillator.frequency.exponentialRampToValueAtTime(80,ctx.currentTime+.14);gain.gain.setValueAtTime(.055,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+.17);oscillator.connect(gain);gain.connect(ctx.destination);oscillator.start();oscillator.stop(ctx.currentTime+.17);setTimeout(()=>ctx.close(),340)}catch(e){console.warn('Sound unavailable:',e)}}
const canvas=$('fxCanvas'),ctx=canvas.getContext('2d');let frame=0,canvasDpr=1;
function resizeFx(){canvasDpr=Math.min(2,devicePixelRatio||1);canvas.width=Math.round(innerWidth*canvasDpr);canvas.height=Math.round(innerHeight*canvasDpr);ctx.setTransform(canvasDpr,0,0,canvasDpr,0,0)}resizeFx();window.addEventListener('resize',resizeFx);
function spawnFinisher({x,y},forcedMode=null){const motion=matchMedia('(prefers-reduced-motion: reduce)').matches;const mode=forcedMode|| (STORE.prefs.effect==='random'?['shatter','fireworks','shot','slash','burn','arrow','frost','thunder'][Math.floor(Math.random()*8)]:STORE.prefs.effect);if(mode==='off'||motion||STORE.prefs.vfxIntensity==='off'){playClick();return}playClick();const layer=$('impactLayer');const flash=document.createElement('span');flash.className='impact-flash '+mode;flash.style.left=x+'px';flash.style.top=y+'px';layer.appendChild(flash);setTimeout(()=>flash.remove(),520);
 const word=document.createElement('span');word.className='impact-word';word.style.left=x+'px';word.style.top=y+'px';word.textContent=({shot:'CRITICAL HIT!',shatter:'SHATTERED!',slash:'SWORD STRIKE!',burn:'DRAGONFIRE!',arrow:'BULLSEYE!',frost:'FROSTBITE!',thunder:'LIGHTNING!',fireworks:'QUEST CLEARED!'})[mode]||'QUEST CLEARED!';layer.appendChild(word);setTimeout(()=>word.remove(),820);
 if(mode==='shatter'||mode==='shot'){for(let i=0;i<Math.round((mode==='shatter'?38:15)*(STORE.prefs.vfxIntensity==='subtle'?.25:STORE.prefs.vfxIntensity==='vivid'?.60:1));i++){const a=Math.random()*Math.PI*2,r=50+Math.random()*180,shard=document.createElement('span');shard.className='glass-shard';const values={'--x':x+'px','--y':y+'px','--w':(5+Math.random()*18)+'px','--h':(7+Math.random()*21)+'px','--dx':Math.cos(a)*r+'px','--dy':Math.sin(a)*r*.75+'px','--rot':(Math.random()*940-470)+'deg','--dur':(650+Math.random()*400)+'ms'};for(const [k,v]of Object.entries(values))shard.style.setProperty(k,v);layer.append(shard);setTimeout(()=>shard.remove(),1100)} }
 if(mode==='shot'){const el=document.elementFromPoint(Math.max(0,x),Math.max(0,y))?.closest('.mod-row');if(el){el.classList.add('shot-hit');setTimeout(()=>el.classList.remove('shot-hit'),800)}}
 if(['slash','burn','arrow','frost','thunder','shatter'].includes(mode))drawCombatFinisher(mode,{x,y});
 const density=STORE.prefs.vfxIntensity==='subtle'?.24:STORE.prefs.vfxIntensity==='vivid'?.60:1;const n=Math.ceil((mode==='fireworks'?125:mode==='shatter'?68:mode==='burn'?110:75)*density);for(let i=0;i<n;i++){const theta=Math.random()*Math.PI*2,speed=(mode==='fireworks'?1.1:1.7)+Math.random()*(mode==='fireworks'?6.1:4.1);activeFx.push({x,y,vx:Math.cos(theta)*speed,vy:Math.sin(theta)*speed-((mode==='fireworks')?1.5:0),life:1,loss:.012+Math.random()*.017,size:1+Math.random()*3,hue:(mode==='burn'?[9,20,38,52]:mode==='frost'?[186,192,208,227]:mode==='thunder'?[44,55,190,268]:mode==='slash'?[171,190,211,345]:[42,163,191,352])[Math.floor(Math.random()*4)],shape:Math.random()>.7?'square':'circle',gravity:mode==='burn'?-0.025-Math.random()*.052:.035+Math.random()*.06})}if(!frame)frame=requestAnimationFrame(animateFx)}
function animateFx(){ctx.clearRect(0,0,innerWidth,innerHeight);activeFx=activeFx.filter(p=>p.life>0);for(const p of activeFx){p.x+=p.vx;p.y+=p.vy;p.vy+=p.gravity;p.vx*=.992;p.life-=p.loss;ctx.globalAlpha=Math.max(0,p.life);ctx.fillStyle=`hsl(${p.hue} 95% ${58+20*p.life}%)`;ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=12*p.life;if(p.shape==='square')ctx.fillRect(p.x,p.y,p.size*1.4,p.size*1.4);else{ctx.beginPath();ctx.arc(p.x,p.y,p.size,0,Math.PI*2);ctx.fill()}}ctx.globalAlpha=1;ctx.shadowBlur=0;if(activeFx.length)frame=requestAnimationFrame(animateFx);else{frame=0;ctx.clearRect(0,0,innerWidth,innerHeight)}}
// Full-profile boss finale. The visual spectacle never grants progress or XP.
const victoryReducedMotion=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
function victoryDecorate(){const sky=$('victorySky'),runes=$('victoryRunes');sky.replaceChildren();runes.replaceChildren();const count=victoryReducedMotion()?0:150;for(let i=0;i<count;i++){const a=Math.random()*Math.PI*2,d=110+Math.random()*Math.max(innerWidth,innerHeight)*.8;const shard=document.createElement('i');shard.className='victory-shard';shard.style.setProperty('--dx',Math.round(Math.cos(a)*d)+'px');shard.style.setProperty('--dy',Math.round(Math.sin(a)*d)+'px');shard.style.setProperty('--rot',Math.round(Math.random()*1500-750)+'deg');shard.style.setProperty('--w',(3+Math.random()*15)+'px');shard.style.setProperty('--h',(8+Math.random()*30)+'px');shard.style.setProperty('--dur',(850+Math.random()*900)+'ms');shard.style.setProperty('--delay',(Math.random()*900)+'ms');sky.append(shard)}
 const glyphs='ᛟᚨᛝᚱᚷᛉᛞᛠᛤᚺᛦ';for(let i=0;i<(victoryReducedMotion()?0:44);i++){const rune=document.createElement('i');rune.textContent=glyphs[Math.floor(Math.random()*glyphs.length)];rune.style.left=Math.round(Math.random()*100)+'%';rune.style.top=Math.round(Math.random()*100)+'%';rune.style.animationDelay=(Math.random()*2)+'s';rune.style.fontSize=(15+Math.random()*24)+'px';runes.append(rune)} }
function playVictoryFanfare(){if(!STORE.prefs.sound)return;try{const A=window.AudioContext||window.webkitAudioContext;if(!A)return;const context=new A();const notes=[196,294,392,494,587,784,987,1174];let t=context.currentTime+.12;notes.forEach((hz,i)=>{const osc=context.createOscillator(),gain=context.createGain();osc.type=i===notes.length-1?'sine':'triangle';osc.frequency.value=hz;const at=t+i*.15;gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(.052,at+.04);gain.gain.exponentialRampToValueAtTime(.0001,at+(i===notes.length-1?.7:.24));osc.connect(gain);gain.connect(context.destination);osc.start(at);osc.stop(at+(i===notes.length-1?.74:.25))});setTimeout(()=>context.close().catch(()=>{}),2800)}catch(ex){console.warn('Optional celebration audio not available',ex.message)}}
function victoryBlast(){VICTORY_TIMERS.forEach(clearTimeout);VICTORY_TIMERS=[];victoryDecorate();const ov=$('victoryOverlay');ov.classList.remove('victory-restart');void ov.offsetWidth;ov.classList.add('victory-restart');if(victoryReducedMotion())return;
 const types=['thunder','shatter','slash','burn','frost','shot','fireworks','arrow','fireworks','burn','shatter','thunder','fireworks','fireworks'];
 types.forEach((mode,i)=>{VICTORY_TIMERS.push(setTimeout(()=>{if($('victoryOverlay').hidden)return;const old=STORE.prefs.effect;STORE.prefs.effect=mode;spawnFinisher({x:innerWidth*(.15+Math.random()*.7),y:innerHeight*(.18+Math.random()*.65)});STORE.prefs.effect=old},i*190+300))})}
function launchVictory(record,practice){if(VICTORY_ACTIVE)return;VICTORY_ACTIVE={record,practice};$('victoryOverlay').hidden=false;document.body.classList.add('victory-open');$('victoryTier').textContent=practice?'PRACTICE · A TASTE OF SOVNGARDE':'WORLD-EATER DEFEATED · VERIFIED FULL CLEAR';$('victoryTitle').innerHTML=practice?'A LEGEND <em>AWAKENS.</em>':'SOVNGARDE <em>IS YOURS.</em>';
 $('victorySubtitle').textContent=practice?'This is a cinematic preview. Rank and trophies require a verified MO2 update and fresh completed deep Nexus audit.':`A flawless expedition! ${Number(record.verifiedMods||0)} Nexus-linked mods cleared in a fresh full audit. Your legend enters the Chronicle.`;
 SET('victoryMods',Number(record.verifiedMods||0).toLocaleString());SET('victoryXP','+'+Number(record.bonus||0).toLocaleString()+' XP');SET('victoryScore',practice?'PRACTICE':Number(GAME?.score||0).toLocaleString());SET('victoryEvidence',practice?'NO XP, RANK, OR TROPHIES AWARDED · PREVIEW ONLY':'MO2 update evidence + full Nexus audit · saved permanently to the profile');$('victoryClaim').focus({preventScroll:true});playVictoryFanfare();victoryBlast();}
async function closeVictory(){if(!VICTORY_ACTIVE)return;const record=VICTORY_ACTIVE.record,practice=VICTORY_ACTIVE.practice;VICTORY_ACTIVE=null;VICTORY_TIMERS.forEach(clearTimeout);VICTORY_TIMERS=[];$('victoryOverlay').hidden=true;document.body.classList.remove('victory-open');$('victorySky').replaceChildren();$('victoryRunes').replaceChildren();if(!practice&&BRIDGE.active&&record?.id&&LIVE_CATALOG){try{await bridgeRequest('POST','victory/ack',{profileId:LIVE_CATALOG.profileId,victoryId:record.id});await refreshGame()}catch(ex){toast('Victory stored in MO2; acknowledgment pending: '+ex.message)}}}
$('previewVictory').onclick=()=>launchVictory({verifiedMods:BRIDGE.active?(DATA.items.filter(x=>x.nexusId).length):DATA.items.length,bonus:0,updates:counts().done},true);
$('raidAction').onclick=()=>BRIDGE.active&&LIVE_CATALOG?scanLive('deep'):launchVictory({verifiedMods:DATA.items.length,bonus:0,updates:counts().done},true);
$('victoryClaim').onclick=closeVictory;$('victoryReplay').onclick=()=>VICTORY_ACTIVE&&victoryBlast();
// Centralized controls: the list is fully rendered, with event delegation and no viewport record caps.
$('modList').addEventListener('pointerover',e=>{const r=e.target.closest('.mod-row');if(r)window.AetherFX?.hover(r)});
$('modList').addEventListener('click',e=>{const togg=e.target.closest('[data-chapter-toggle]');if(togg){const id=togg.dataset.chapterToggle;STORE.prefs.collapsed=STORE.prefs.collapsed.includes(id)?STORE.prefs.collapsed.filter(x=>x!==id):[...STORE.prefs.collapsed,id];save();render();return}
 const row=e.target.closest('.mod-row');const act=e.target.closest('[data-act]');if(!act){if(e.target.id==='emptyReset')resetFilters();if(row){const hit=ITEM_MAP.get(row.dataset.id);if(hit){focusedRowId=hit.id;window.AetherFX?.select(row,{source:'app'});if(BRIDGE.active)locateInMO2(hit,row)}}return}const m=ITEM_MAP.get(act.dataset.id);if(!m)return;if(row&&act.dataset.act!=='complete'){focusedRowId=m.id;window.AetherFX?.select(row,{source:'app'})}
 if(act.dataset.act==='complete'){e.preventDefault();focusedRowId=m.id;toggleDone(m.id,act)}
 if(act.dataset.act==='locate'){e.preventDefault();locateInMO2(m,act);return}
 if(act.dataset.act==='files'){e.preventDefault();openFilePicker(m);return}
 if(act.dataset.act==='inspect'){e.preventDefault();drawInspector(m)}
 if(act.dataset.act==='favorite'){e.preventDefault();window.AetherFX?.favorite(act);STORE.rows[m.id]={...getRow(m.id),favorite:!isFav(m)};save();render();toast(isFav(m)?'★ Bookmarked '+m.name:'Bookmark removed')}
 if(act.dataset.act==='source'){STORE.rows[m.id]={...getRow(m.id),lastOpened:new Date().toISOString()};save()}
});
$('chapters').addEventListener('click',e=>{const b=e.target.closest('[data-chapter]');if(b)jumpChapter(b.dataset.chapter)});
$('chapterSearch').addEventListener('input',renderChapters);
$all('[data-filter]').forEach(b=>b.addEventListener('click',()=>{STORE.prefs.filter=b.dataset.filter;save();render()}));
$('sortSelect').addEventListener('change',e=>updatePrefs({sort:e.target.value}));
$('search').value=STORE.prefs.query;$('search').addEventListener('input',e=>{STORE.prefs.query=e.target.value;save();render()});
$('clearSearch').addEventListener('click',()=>{STORE.prefs.query='';$('search').value='';save();render();$('search').focus()});
$('clearFilters').onclick=resetFilters;
$('collapseAll').onclick=toggleAllChapters;
$('densityToggle').onclick=()=>updatePrefs({density:STORE.prefs.density==='compact'?'comfy':'compact'});
$('focusToggle').onclick=()=>updatePrefs({focus:!STORE.prefs.focus});
$('focusTop').onclick=()=>updatePrefs({focus:!STORE.prefs.focus});
$('effectSelect').onchange=e=>updatePrefs({effect:e.target.value});$('fxSettingsToggle').onclick=()=>{const panel=$('fxStudio');panel.hidden=!panel.hidden;$('fxSettingsToggle').setAttribute('aria-expanded',String(!panel.hidden))};$('fxIntensity').onchange=e=>updatePrefs({vfxIntensity:e.target.value});$('fxShake').onchange=e=>updatePrefs({vfxShake:e.target.checked});$('fxTrails').onchange=e=>updatePrefs({vfxTrails:e.target.checked});$('fxTest').onclick=()=>{if(STORE.prefs.vfxIntensity==='off'||matchMedia('(prefers-reduced-motion: reduce)').matches){toast('✧ Preview unavailable while visual effects are disabled or Reduced Motion is enabled.');return}window.AetherFX?.preview();toast('✧ Visual preview · no progress or ranked XP')};$('fxClose').onclick=()=>{$('fxStudio').hidden=true;$('fxSettingsToggle').setAttribute('aria-expanded','false')};$('fxStudioDone').onclick=$('fxClose').onclick;
$('soundToggle').onclick=()=>updatePrefs({sound:!STORE.prefs.sound});
$('themeToggle').onclick=()=>updatePrefs({theme:STORE.prefs.theme==='night'?'snow':'night'});
$('nextPending').onclick=nextPending;$('showCritical').onclick=()=>{STORE.prefs.filter='risky';STORE.prefs.query='';$('search').value='';STORE.prefs.collapsed=[];save();render();$('workbench')?.scrollIntoView({behavior:'smooth'})};
$('backToTop').onclick=()=>scrollTo({top:0,behavior:'smooth'});
$('advisoryToggle').onclick=()=>{const s=document.querySelector('.advisory');s.classList.toggle('collapsed');$('advisoryBody').hidden=s.classList.contains('collapsed');$('advisoryToggle').setAttribute('aria-expanded',String(!s.classList.contains('collapsed')))};
$('exportTop').onclick=exportJSON;$('backupBtn').onclick=exportJSON;$('sidebarBackup').onclick=exportJSON;$('csvBtn').onclick=exportCSV;
$('importBtn').onclick=()=>$('importFile').click();$('importFile').onchange=e=>importJSON(e.target.files?.[0]);
$('mo2Btn').onclick=mo2Open;$('mo2Close').onclick=mo2Close;$('mo2Veil').addEventListener('click',e=>{if(e.target===$('mo2Veil'))mo2Close()});
$('mo2Download').onclick=()=>saveFile('MO2_Source_Exporter.ps1','text/plain',MO2_EXPORTER);
$('mo2Import').onclick=()=>$('mo2File').click();$('mo2File').onchange=e=>importMO2(e.target.files?.[0]);$('mo2Lookup').oninput=drawMO2Matcher;$('mo2From').onchange=mo2UpdatePreview;$('mo2To').onchange=mo2UpdatePreview;$('mo2Bind').onclick=bindMO2Match;
$('drawerClose').onclick=closeInspector;$('drawerVeil').onclick=closeInspector;
$('helpToggle').onclick=()=>help(true);$('helpClose').onclick=()=>help(false);$('helpOK').onclick=()=>help(false);$('helpVeil').addEventListener('click',e=>{if(e.target===$('helpVeil'))help(false)});
$('menuToggle').onclick=()=>$('sidebar').classList.toggle('open');document.addEventListener('click',e=>{if(!$('fxStudio').hidden&&!e.target.closest('#fxStudio')&&!e.target.closest('#fxSettingsToggle')){$('fxStudio').hidden=true;$('fxSettingsToggle').setAttribute('aria-expanded','false')}if($('sidebar').classList.contains('open')&&!e.target.closest('#sidebar')&&!e.target.closest('#menuToggle'))$('sidebar').classList.remove('open')});
document.addEventListener('keydown',e=>{const inField=e.target.matches('input,textarea,select,[contenteditable]');if(e.key==='Escape'){$('fxStudio').hidden=true;$('fxSettingsToggle').setAttribute('aria-expanded','false');closeInspector();help(false);mo2Close();closeFilePicker();closeVictory();$('sidebar').classList.remove('open');if(inField)e.target.blur();return}
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();closeInspector();$('search').focus();$('search').select();return}
 if(inField||!$('helpVeil').hidden||!$('mo2Veil').hidden||$('detailDrawer').classList.contains('open'))return;
 if(e.key.toLowerCase()==='f'){e.preventDefault();updatePrefs({focus:!STORE.prefs.focus});return}if(e.key.toLowerCase()==='n'){e.preventDefault();nextPending();return}if(e.key==='?'||e.key==='F1'){e.preventDefault();help(true);return}
 if(e.key.toLowerCase()==='j'||e.key.toLowerCase()==='k'){e.preventDefault();const ids=filtered().filter(m=>!STORE.prefs.collapsed.includes(m.groupId)).map(m=>m.id);if(!ids.length)return;let i=ids.indexOf(focusedRowId);i=(i+(e.key.toLowerCase()==='j'?1:-1)+ids.length)%ids.length;focusRow(ids[i]);return}
 if(e.code==='Space'&&focusedRowId){e.preventDefault();toggleDone(focusedRowId,$('row-'+focusedRowId)?.querySelector('[data-act="complete"]'))}
});
// No remote privileges in the browser; the plugin serves a tokenized same-origin loopback endpoint.
async function bridgeRequest(method,path,body){
 if(!BRIDGE.active)throw Error('Launch the app from the MO2 plugin to connect');
 const controller=new AbortController(),tm=setTimeout(()=>controller.abort(),method==='GET'?24000:195000);
 try{const r=await fetch('/api/'+path,{method,headers:{'X-Arsenal-Token':BRIDGE.token,...(method==='POST'?{'Content-Type':'application/json'}:{})},body:method==='POST'?JSON.stringify(body||{}):undefined,cache:'no-store',signal:controller.signal});const j=await r.json();if(!r.ok||j.ok===false)throw Error(j.error||'Bridge request rejected');return j}finally{clearTimeout(tm)}
}
function activateLiveCatalog(c){
 if(!c||!Array.isArray(c.items)||!Array.isArray(c.groups)||!c.profileId)throw Error('Invalid profile snapshot');
 const newProfile=LIVE_CATALOG?.profileId!==c.profileId;
 if(newProfile&&STORAGE.startsWith('mo2-update-arsenal:')&&PROGRESS_READY)save();
 LIVE_CATALOG=c;DATA=c;ITEM_MAP=new Map(c.items.map(m=>[m.id,m]));GROUP_MAP=new Map(c.groups.map(g=>[g.id,g]));STORAGE='mo2-update-arsenal:v2:'+c.profileId;
 if(newProfile){clearTimeout(PROGRESS_TIMER);PROGRESS_READY=false;GAME=null;GAME_SEEN=-1;NATIVE_SELECTED='';focusedRowId='';STORE=structuredClone(BASE);load();}
 STORE.prefs.collapsed=(Array.isArray(STORE.prefs.collapsed)?STORE.prefs.collapsed:[]).filter(id=>GROUP_MAP.has(id));$('search').value=STORE.prefs.query;
 const currentRuntime=c.gameRuntime||'unknown';let changedRuntime=false,changedMods=0;
 if(STORE.verifiedRuntime&&STORE.verifiedRuntime!==currentRuntime){for(const [id,row] of Object.entries(STORE.rows)){if(row.compat==='compatible'){delete row.compat;if(row.status==='done')row.status='review';changedRuntime=true}}}
 for(const m of c.items){const row=STORE.rows[m.id];if(row?.status==='done'&&row.observedInstalledVersion&&row.observedInstalledVersion!==m.installedVersion){row.status='review';changedMods++}}
 STORE.verifiedRuntime=currentRuntime;
 if(changedRuntime||changedMods)save();
 const r=currentRuntime;$('runtimeBadge').innerHTML=`<span class="status-light"></span><div><strong>${escapeHTML(c.game||'ACTIVE GAME')} / ${escapeHTML(c.profileName)}</strong><span>Target runtime: <b>${escapeHTML(r)}</b> · ${c.items.length} installed mods</span></div><span class="runtime-lock">LIVE MO2</span>`;
 $('referenceLinks').innerHTML=`<a href="https://www.nexusmods.com/${encodeURIComponent(c.game||'skyrimspecialedition')}" target="_blank" rel="noopener noreferrer">Nexus ${escapeHTML(c.game||'Game')} ↗</a><span>•</span><a href="https://www.nexusmods.com/users/myaccount?tab=api" target="_blank" rel="noopener noreferrer">Nexus account ↗</a>`;
 $('heroSummary').innerHTML=`Your active <strong>${escapeHTML(c.profileName)}</strong> profile in <strong>${escapeHTML(c.game||'MO2')}</strong>. Navigate installed mods, inspect verified metadata, queue files into MO2, and celebrate every safe update. Runtime ${escapeHTML(r)}; double-check native DLLs and requirements.`;
 $('advisoryToggle').querySelector('b').textContent='LIVE UPDATE SAFETY PROTOCOL';
 $('advisoryBody').innerHTML='<div><span>01 / RUNTIME</span><strong>Match executable + script extender.</strong><p>Native DLL releases must match this game runtime. Check each file description.</p></div><div><span>02 / DEPENDENCIES</span><strong>Check masters and requirements.</strong><p>Verify mod dependencies, ESL records, plugins and update steps.</p></div><div><span>03 / SAVE SAFETY</span><strong>Read changelogs before upgrades.</strong><p>Save-breaking changes, FOMOD variants, mid-save warnings and generated behaviors may require special handling.</p></div><div><span>04 / CONTROLLED INSTALL</span><strong>MO2 stays in charge.</strong><p>Back up the profile, download through MO2 and install with normal prompts. Nothing silently overwrites your load order.</p></div>';
 $('riskSubtitle').textContent='DLLs + runtime + risky masters';document.querySelector('.pagefooter').children[1].textContent='LOCAL-FIRST ARSENAL · LIVE MO2 + NEXUS INTELLIGENCE · PROFILE SAVE';document.querySelector('.pagefooter').firstElementChild.textContent=`ᛟ MO2 LIVE / ${c.game} / ${c.profileName}`;
 SET('liveProfile',c.profileName+' / '+c.game);SET('liveCount',c.items.length+' mods · '+c.groups.length+' chapters');SET('liveState','Live session. Your active MO2 profile is authoritative; the checklist is saved per profile.');$('livePill').textContent='● MO2 CONNECTED';$('livePill').classList.add('connected');
 $('liveSync').textContent='Snapshot: '+new Date().toLocaleTimeString();
 for(const id of ['liveAll','liveQuick','liveDeep','liveLocal','liveRefresh','liveRuntime','liveConnect','liveBackup'])$(id).disabled=false;
 const chosen=STORE.prefs.filter;if(chosen==='updates'&&!c.items.some(isUpdate))STORE.prefs.filter='all';
 if(newProfile||changedRuntime||changedMods){WORKSHOP_PLAN=null;WORKSHOP_CHOICES.clear()}
 applyAppearance();updateStorageIndicator();render();renderLiveStats();if(newProfile){hydrateProgress(c.profileId);refreshGame()}refreshWorkshop().catch(ex=>workshopSetStatus('Plan unavailable: '+ex.message));if(changedRuntime||changedMods)toast('⚠ Previous cleared checks need review: runtime or installed version changed.');
}

function workshopSource(item){
 const u=getSrc(item),link=validUrl(u.url);
 return link&&u.verified?link:'';
}
function workshopLocalPlan(){
 const summary={candidates:0,review:0,manual:0,current:0,risky:0,total:DATA.items.length};
 const items=DATA.items.map(m=>{
  const verdict=m.update?.verdict||'unverified';
  const lane=verdict==='candidate'?'candidate':['current','newer-installed'].includes(verdict)?'current':!Number(m.nexusId||0)?'manual':'review';
  summary[({candidate:'candidates',review:'review',manual:'manual',current:'current'})[lane]]++;
  const risky=isRisk(m);if(risky)summary.risky++;
  return{id:m.id,name:m.name,nexusId:Number(m.nexusId||0),installedVersion:m.installedVersion||'',latestVersion:m.update?.latestVersion||'',verdict,lane,priority:m.priority,group:m.group,risks:risky?['Review compatibility and installation prerequisites']:[],sourceUrl:workshopSource(m),sourceVerified:!!workshopSource(m),provider:m.update?.provider||m.source?.type||'unknown',releaseAssets:m.update?.releaseAssets||[]};
 });
 return{ok:true,profileId:LIVE_CATALOG?.profileId||'',profileName:LIVE_CATALOG?.profileName||'Standalone sample',game:DATA.game||'skyrimspecialedition',gameRuntime:DATA.gameRuntime||'unknown',summary,items};
}
function currentWorkshopPlan(){return WORKSHOP_PLAN||workshopLocalPlan()}
function workshopSetStatus(value){SET('workshopStatus',value)}
function renderWorkshop(){
 const area=$('workshopResults');if(!area)return;
 const plan=currentWorkshopPlan(),summary=plan.summary,filter=$('workshopFilter').value||'candidate',query=$('workshopSearch').value.trim().toLowerCase();
 const selected=[...WORKSHOP_CHOICES.values()].filter(x=>x.profileId===plan.profileId);
 SET('workshopCount',summary.candidates+' CANDIDATES · '+selected.length+' REVIEWED');
 $('workshopSummary').innerHTML=[['Candidates',summary.candidates],['Investigate',summary.review],['Manual sources',summary.manual],['Current',summary.current],['Compatibility watch',summary.risky]].map(([name,n])=>'<div class="workshop-metric"><strong>'+escapeHTML(n)+'</strong><small>'+escapeHTML(name)+'</small></div>').join('');
 const visible=plan.items.filter(m=>(filter==='all'||m.lane===filter)&&(!query||[m.name,m.group,m.installedVersion,m.latestVersion,m.verdict].join(' ').toLowerCase().includes(query)));
 area.innerHTML=visible.map(m=>{
  const choice=WORKSHOP_CHOICES.get(m.id);
  const src=m.sourceUrl||getSrc(ITEM_MAP.get(m.id)||{id:m.id,name:m.name,group:m.group,source:{}}).url;
  const compatible=m.lane==='candidate',warning=m.risks?.length;
  return '<article class="workshop-item" data-workshop-id="'+escapeHTML(m.id)+'"><div class="workshop-item-main"><div class="workshop-line"><span class="workshop-lane lane-'+escapeHTML(m.lane)+'">'+escapeHTML(m.lane.toUpperCase())+'</span><strong>'+escapeHTML(m.name)+'</strong></div><small>'+escapeHTML(m.group||'MO2 profile')+' · '+escapeHTML(m.installedVersion||'?')+' → '+escapeHTML(m.latestVersion||'?')+'</small><div class="workshop-tags">'+(warning?'<span class="workshop-warning">⚠ '+escapeHTML(m.risks.join(' · '))+'</span>':'')+(choice?'<span class="workshop-selected">✓ Reviewed file #'+(choice.fileId||choice.assetId)+'</span>':'')+'</div></div><div class="workshop-item-actions"><a target="_blank" rel="noopener noreferrer" href="'+escapeHTML(src)+'">↗ Source</a>'+(BRIDGE.active&&compatible&&(m.nexusId||m.releaseAssets?.length)?'<button type="button" class="quiet-button" data-workshop-act="review" data-id="'+escapeHTML(m.id)+'">'+(choice?'Change file':'Review files')+'</button>':'')+'</div></article>';
 }).join('')||'<div class="workshop-empty">No mods in this lane. Change the filter or run a deeper audit.</div>';
 $('workshopQueue').disabled=!BRIDGE.active||!selected.length||WORKSHOP_BUSY;
 $('workshopRefresh').disabled=WORKSHOP_BUSY;
 $('workshopExport').disabled=WORKSHOP_BUSY;
}
async function refreshWorkshop(){
 if(!BRIDGE.active){WORKSHOP_PLAN=workshopLocalPlan();renderWorkshop();workshopSetStatus('Standalone checklist ready. No live MO2 installation or download actions are available.');return}
 const profile=LIVE_CATALOG?.profileId;
 if(!profile)return;
 const p=await bridgeRequest('GET','update-plan');
 if(LIVE_CATALOG?.profileId!==profile||p.profileId!==profile)return;
 WORKSHOP_PLAN=p;
 for(const [id,choice] of WORKSHOP_CHOICES)if(choice.profileId!==profile||!p.items.some(m=>m.id===id&&m.lane==='candidate'&&m.installedVersion===choice.installedVersion))WORKSHOP_CHOICES.delete(id);
 renderWorkshop();workshopSetStatus('Plan is based on the active MO2 profile. Select exact files individually before queueing.');
}
function exportWorkshop(){
 const plan=currentWorkshopPlan();
 const data={format:'Modhunter Reviewed Update Plan',version:1,exportedAt:new Date().toISOString(),profileId:plan.profileId,profileName:plan.profileName,game:plan.game,gameRuntime:plan.gameRuntime,summary:plan.summary,items:plan.items,reviewedFiles:[...WORKSHOP_CHOICES.values()]};
 saveFile('Modhunter-Update-Plan-'+(plan.profileName||'Standalone').replace(/[^\w-]+/g,'-')+'.json','application/json',JSON.stringify(data,null,2));
 workshopSetStatus('Exported the full plan, including manual/unlinked mods and any explicit file reviews.');
}
async function reviewWorkshopFile(id){
 const m=ITEM_MAP.get(id);if(!m||!BRIDGE.active||(!m.nexusId&&!m.update?.releaseAssets?.length))return;
 const plan=currentWorkshopPlan(),record=plan.items.find(x=>x.id===id);
 if(!record||record.lane!=='candidate'){toast('This mod needs a fresh Nexus scan or manual review.');return}
 WORKSHOP_REVIEW_ID=id;
 await openFilePicker(m);
 const panel=$('filePickerFiles');
 panel.querySelectorAll('button[data-file-id]').forEach(b=>b.textContent='✓ Select for batch');
 $('filePickerSummary').textContent='Review the exact file, its requirements and '+(plan.gameRuntime||'unknown')+' runtime compatibility. Selecting only prepares a reviewed download; nothing installs automatically.';
}
async function queueWorkshop(){
 if(WORKSHOP_BUSY||!BRIDGE.active)return;
 const plan=currentWorkshopPlan(),profile=plan.profileId;
 const entries=[...WORKSHOP_CHOICES.values()].filter(x=>x.profileId===profile);
 if(!entries.length)return;
 if(!confirm('Queue '+entries.length+' reviewed file choices in MO2? This downloads only. Installation still requires separate prompts for each archive.'))return;
 WORKSHOP_BUSY=true;renderWorkshop();
 let sent=0;const problems=[],seen=new Set();
 try{
  const latest=await bridgeRequest('GET','update-plan');
  if(latest.profileId!==profile||LIVE_CATALOG?.profileId!==profile)throw Error('Active profile changed. Reopen the Workshop.');
  const response=await bridgeRequest('POST','update-queue',{profileId:profile,confirm:'QUEUE_REVIEWED_DOWNLOADS',entries});
  for(const item of response.queued||[]){sent++;WORKSHOP_CHOICES.delete(item.itemId)}
  for(const item of response.failed||[])problems.push(item.itemId+': '+item.error);
  await refreshDownloads();
  workshopSetStatus('Queued '+sent+' reviewed file(s). '+(problems.length?'Needs attention: '+problems.join(' | '):'Install each completed file using the MO2 installer.'));
 }catch(e){workshopSetStatus('Queue halted: '+e.message)}
 finally{WORKSHOP_BUSY=false;renderWorkshop()}
}
$('workshopRefresh').onclick=()=>refreshWorkshop().catch(e=>workshopSetStatus('Plan failed: '+e.message));
$('workshopExport').onclick=exportWorkshop;
$('workshopQueue').onclick=queueWorkshop;
$('workshopFilter').onchange=renderWorkshop;
$('workshopSearch').oninput=renderWorkshop;
$('workshopResults').addEventListener('click',e=>{const b=e.target.closest('[data-workshop-act="review"]');if(b)reviewWorkshopFile(b.dataset.id).catch(ex=>workshopSetStatus('Review failed: '+ex.message))});

function renderLiveStats(){if(!BRIDGE.active||!LIVE_CATALOG)return;const items=DATA.items;const found=items.filter(isUpdate).length;const reviewed=items.filter(m=>m.update?.verdict==='review').length;SET('liveUpdateCount',found+' update candidates');SET('liveCached',reviewed+' need version review · not installation approval');}
function paintNativeSelection(){const target=focusedRowId||NATIVE_SELECTED;$all('.mod-row').forEach(row=>{row.classList.toggle('native-selected',BRIDGE.active&&row.dataset.id===NATIVE_SELECTED);row.classList.toggle('aether-target',Boolean(target&&row.dataset.id===target))})}
async function locateInMO2(m,el){if(!BRIDGE.active||!LIVE_CATALOG){toast('Open from MO2 to reveal a mod.');return}const profile=LIVE_CATALOG.profileId;el.disabled=true;
 try{const r=await bridgeRequest('POST','focus',{id:m.id,profileId:profile});if(LIVE_CATALOG?.profileId!==profile)return;NATIVE_SELECTED=m.id;paintNativeSelection();window.AetherFX?.reveal($('row-'+m.id));toast('⌖ '+(r.message||'MO2 jumped to '+m.name));}
 catch(ex){toast('MO2 navigation: '+ex.message)}finally{el.disabled=false}}
function questRank(score){if(score>=20000)return'LEGENDARY DRAGONBORN';if(score>=9000)return'ARCHMAGE OF THE FORGE';if(score>=3500)return'EBONY SENTINEL';if(score>=1000)return'SKYFORGE KNIGHT';if(score>=250)return'IRON VANGUARD';return'NOVICE ADVENTURER'}
function renderQuest(){if(!$('gameBoard'))return;const c=counts(),isLive=Boolean(BRIDGE.active&&LIVE_CATALOG),score=isLive?Number(GAME?.score||0):c.done*10,updates=isLive?Number(GAME?.updates||0):c.done;
 SET('questLevel',isLive?(GAME?.level||1):(1+Math.floor(c.done/15)));SET('questRank',questRank(score));SET('questScore',score.toLocaleString()+' XP');SET('questUpdates',isLive?`${updates} verified MO2 updates`:`${updates} practice checklist clears`);SET('questRankHint',isLive?'NATIVE MO2 VERIFICATION · PERSISTENT':'PRACTICE ONLY · NO VERIFIED SCORE');SET('questCombo',isLive?(GAME?.bestCombo||0)+' ×':'0 ×');SET('questCrowns',isLive?(GAME?.victories||0)+' ♛':'0 ♛');
 const badges=isLive?(GAME?.achievements||BADGE_META.map(([id,name,glyph,target])=>({id,name,glyph,target,unlocked:false}))):BADGE_META.map(([id,name,glyph,target])=>({id,name,glyph,target,unlocked:false}));
 $('achievementGrid').innerHTML=badges.map(b=>`<div class="achievement ${b.unlocked?'unlocked':'locked'}" title="${escapeHTML(b.description||((b.target||0)+' verified updates'))}"><span class="achievement-glyph">${escapeHTML(b.glyph)}</span><div><strong>${escapeHTML(b.name)}</strong><small>${b.unlocked?'UNLOCKED':b.target===null?'Defeat the World-Eater':b.target+' verified updates'}</small></div><i>${b.unlocked?'✦':'🔒'}</i></div>`).join('');SET('achievementCount',badges.filter(b=>b.unlocked).length+' / '+badges.length);
 const feed=isLive?(GAME?.feed||[]):[];$('questFeed').innerHTML=feed.length?feed.slice().reverse().map(ev=>`<div class="quest-feed-line"><span>⚔ ${escapeHTML(ev.name)}</span><strong>+${ev.xp} XP</strong><small>${escapeHTML(ev.evidence==='mo2-install-complete'?'MO2 installed':'Version verified')}</small></div>`).join(''):'<span class="quest-empty">Verified update events appear here.</span>';
 const ranks=isLive?(GAME?.leaderboard||[]):[];$('questLeaderboard').innerHTML=ranks.length?ranks.map((g,i)=>`<div class="quest-leaderboard-line"><span>${i===0?'♛':'#'+(i+1)} ${escapeHTML(g.name)}</span><strong>${Number(g.score).toLocaleString()}</strong><small>${g.victories} crowns</small></div>`).join(''):'<span class="quest-empty">No ranked expeditions yet.</span>';
 const linked=DATA.items.filter(x=>Number(x.nexusId||0)>0),foes=linked.filter(x=>x.update?.verdict==='candidate').length,needs=linked.filter(x=>!['current','newer-installed'].includes(x.update?.verdict)).length,pct=isLive&&LIVE_SCAN?.state==='completed'&&LIVE_SCAN?.mode==='deep'&&linked.length?Math.max(0,Math.round(100*(linked.length-needs)/linked.length)):0;
 $('raidBossFill').style.width=(isLive?pct:c.percent)+'%';SET('raidStatus',isLive?(LIVE_SCAN?.mode==='deep'&&LIVE_SCAN?.state==='completed'?(needs?`${needs} unverified or outdated. Clear the update queue and rerun the full audit.`:'All tracked Nexus mods verified by a full sweep.'): `Complete updates in MO2, then run a deep Nexus audit to challenge the World-Eater.`):`Your offline practice campaign: ${c.done} of ${c.total} quests checked.`);
 SET('raidNumbers',isLive?`${foes} UPDATE CANDIDATES · ${needs} REQUIRE REVIEW · ${linked.length} NEXUS-LINKED`:`${c.done} / ${c.total} PRACTICE CLEAR`);$('raidAction').textContent=isLive?'⚔ Verify the full profile':'✧ Practice finale';}
async function refreshGame(){if(!BRIDGE.active||!LIVE_CATALOG)return;const profile=LIVE_CATALOG.profileId;try{const r=await bridgeRequest('GET','game');if(LIVE_CATALOG?.profileId!==profile||r.profileId!==profile)return;const last=GAME_SEEN;GAME=r;const sigils=r.realmWallet?.available;const badge=$('realmBalanceBadge');if(badge)badge.textContent='✧ '+(Number.isFinite(sigils)?sigils:0);const feed=r.feed||[];const latest=feed.at(-1);if(last>=0&&latest&&Number(latest.sequence)>last){toast(`⚔ ${latest.name} +${latest.xp} verified XP`);window.AetherFX?.verified(null);spawnFinisher({x:Math.max(180,innerWidth*.55),y:Math.min(innerHeight*.4,320)})}GAME_SEEN=Math.max(last,Number(latest?.sequence||0));renderQuest();if(r.unseenVictory&&!VICTORY_ACTIVE)launchVictory(r.unseenVictory,false)}catch(ex){console.warn('Chronicle:',ex.message)}}
async function initLiveBridge(){
 try{const res=await bridgeRequest('GET','snapshot');LIVE_GENERATION=res.generation||0;activateLiveCatalog(res.catalog);await refreshWorkshop();const s=await bridgeRequest('GET','scan');if(s.scan)updateScanUI(s.scan);await refreshDownloads();await refreshGame()}catch(ex){SET('liveState','Could not reach MO2: '+ex.message);$('livePill').textContent='⚠ DISCONNECTED';toast('MO2 bridge error: '+ex.message)}
}
function updateScanUI(state){LIVE_SCAN=state;const status=state.state||'idle',progress=state.checked||0,total=state.total||0;SET('liveScanProgress',status==='running'?`Scanning ${progress}/${total||'?'}…`:status==='completed'?'✓ Scan complete':status==='partial'?'⚠ Partial results':status==='error'?'⚠ Scan failed':'Awaiting action');if(status==='error')toast('Scan: '+(state.error||'error'));if(status==='completed'||status==='partial'){SET('liveSync',state.mode+' · '+(state.queried||0)+' queried · '+(state.fromCache||0)+' cached');renderLiveStats();renderQuest()}}
async function scanLive(mode){
 for(const id of ['liveQuick','liveDeep','liveLocal','liveAll'])$(id).disabled=true;
 try{const r=await bridgeRequest('POST','scan',{mode});if(r.state==='running'){SET('liveScanProgress','Beginning '+mode+' scan…');clearInterval(SCAN_TIMER);SCAN_TIMER=setInterval(async()=>{try{const v=await bridgeRequest('GET','scan');updateScanUI(v.scan);if(v.scan.state==='completed'||v.scan.state==='partial'){clearInterval(SCAN_TIMER);SCAN_TIMER=null;const snap=await bridgeRequest('GET','snapshot');activateLiveCatalog(snap.catalog);await refreshGame();await refreshWorkshop();toast('ϟ '+mode+' sweep complete!');}else if(v.scan.state==='error'){clearInterval(SCAN_TIMER);SCAN_TIMER=null}}catch(ex){clearInterval(SCAN_TIMER);SCAN_TIMER=null;toast('Scan interrupted: '+ex.message)}finally{if(!SCAN_TIMER||LIVE_SCAN?.state!=='running')for(const id of ['liveQuick','liveDeep','liveLocal','liveAll'])$(id).disabled=false}},1200);}}catch(ex){toast(ex.message);for(const id of ['liveQuick','liveDeep','liveLocal','liveAll'])$(id).disabled=false}
}
async function refreshDownloads(){if(!BRIDGE.active||!LIVE_CATALOG)return;try{const r=await bridgeRequest('GET','downloads');const box=$('liveDownloadList');box.innerHTML=Object.entries(r.downloads||{}).map(([id,d])=>`<div class="download-ticket"><strong>${escapeHTML('MO2 download #'+id)}</strong><span>${escapeHTML((d.provider==='github'?'GitHub · '+d.name:'Nexus #'+d.modId)+' · '+d.status)}</span>${d.status==='complete'?`<button class="quiet-button" data-download-id="${escapeHTML(id)}">Install with MO2 ↗</button>`:''}</div>`).join('');}catch(ex){SET('liveSync','Download status unavailable: '+ex.message)}}
async function openFilePicker(m){if(!BRIDGE.active||(!m.nexusId&&!m.update?.releaseAssets?.length)){toast('No verified download assets for this source.');return}
 FILE_PICKER_MOD=m;$('filePickerTitle').textContent=m.name;$('filePickerSummary').textContent='Installed: '+m.installedVersion+' · Target runtime: '+(DATA.gameRuntime||'unknown')+'. Select the correct Nexus file, read its requirements and verify its edition.';
 $('filePickerVeil').hidden=false;$('filePickerFiles').innerHTML='<div class="picker-loading">Loading exact Nexus Files…</div>';
 if(!m.nexusId){
  const files=m.update?.releaseAssets||[];
  $('filePickerFiles').innerHTML=files.map(f=>'<div class="picker-file"><div class="picker-file-main"><strong>'+escapeHTML(f.name)+'</strong><span>GitHub release · '+Math.round((f.size||0)/1024)+' KB · verify requirements</span></div><button class="button-bright" data-file-id="'+Number(f.assetId)+'" data-source-kind="github">⇩ Select release asset</button></div>').join('');
  $('filePickerSummary').textContent='Public GitHub release assets: verify your game version, requirements, file and installation steps.';
  return;
 }
 try{const j=await bridgeRequest('GET','files?modId='+m.nexusId);if(!j.files.length)throw Error('No files available for this project');$('filePickerFiles').innerHTML=j.files.map(f=>`<div class="picker-file"><div class="picker-file-main"><strong>${escapeHTML(f.name)}</strong><span>v${escapeHTML(f.version||'?')} · ${escapeHTML(f.fileName||'')} · ${escapeHTML(f.sizeInKB||'?')} KB ${f.category===1?' · MAIN FILE':''}</span>${f.description?`<p class="picker-file-desc">${escapeHTML(f.description)}</p>`:''}</div><button class="button-bright" data-file-id="${f.fileId}" data-mod-id="${m.nexusId}">⇩ Queue in MO2</button></div>`).join('');}catch(ex){$('filePickerFiles').innerHTML=`<div class="picker-error">${escapeHTML(ex.message)}<p>Use the original Files page and Mod Manager Download through MO2 if required by your Nexus account.</p></div>`;}}
function closeFilePicker(){$('filePickerVeil').hidden=true;FILE_PICKER_MOD=null;WORKSHOP_REVIEW_ID=null}
$('filePickerClose').onclick=closeFilePicker;$('filePickerCancel').onclick=closeFilePicker;$('filePickerVeil').addEventListener('click',e=>{if(e.target===$('filePickerVeil'))closeFilePicker()});
$('filePickerNexus').onclick=()=>{if(FILE_PICKER_MOD)window.open(getSrc(FILE_PICKER_MOD).url,'_blank','noopener,noreferrer')};
$('filePickerFiles').addEventListener('click',async e=>{const b=e.target.closest('button[data-file-id]');if(!b)return;const m=FILE_PICKER_MOD;if(!m)return;
 if(WORKSHOP_REVIEW_ID){
  const plan=currentWorkshopPlan(),record=plan.items.find(x=>x.id===WORKSHOP_REVIEW_ID);
  if(!record||record.lane!=='candidate'){closeFilePicker();toast('Candidate is no longer current.');return}
  const picked=b.closest('.picker-file'),label=picked?.querySelector('strong')?.textContent||'Selected file';
  if(!confirm('Have you reviewed the description, requirements, runtime and exact file version?\\n\\n'+record.name+'\\n'+label+'\\nFile #'+b.dataset.fileId))return;
  const riskAcknowledged=!record.risks?.length||confirm('Compatibility watch:\\n'+record.risks.join('\\n')+'\\n\\nI checked this file against my target runtime and prerequisites.');
  if(!riskAcknowledged)return;
  const sourceChoice=b.dataset.sourceKind==='github';
  WORKSHOP_CHOICES.set(WORKSHOP_REVIEW_ID,sourceChoice?{kind:'source',itemId:WORKSHOP_REVIEW_ID,assetId:Number(b.dataset.fileId),installedVersion:record.installedVersion,profileId:plan.profileId,reviewed:true,riskAcknowledged}:{kind:'nexus',itemId:WORKSHOP_REVIEW_ID,modId:Number(m.nexusId),fileId:Number(b.dataset.fileId),installedVersion:record.installedVersion,profileId:plan.profileId,reviewed:true,riskAcknowledged});
  closeFilePicker();renderWorkshop();workshopSetStatus('Reviewed '+record.name+'. Use Queue reviewed files when ready.');return;
 }
 if(!confirm('Queue this reviewed archive in MO2? Installation and compatibility review remain your choice.'))return;b.disabled=true;try{const r=b.dataset.sourceKind==='github'?await bridgeRequest('POST','update-queue',{profileId:LIVE_CATALOG.profileId,confirm:'QUEUE_REVIEWED_DOWNLOADS',entries:[{kind:'source',itemId:m.id,assetId:Number(b.dataset.fileId),installedVersion:m.installedVersion,reviewed:true,riskAcknowledged:true}]}):await bridgeRequest('POST','download',{modId:Number(b.dataset.modId),fileId:Number(b.dataset.fileId),confirm:'DOWNLOAD'});toast('⇩ '+r.message);closeFilePicker();await refreshDownloads()}catch(ex){toast('Download: '+ex.message);b.disabled=false}});
$('liveDownloadList').addEventListener('click',async e=>{const b=e.target.closest('button[data-download-id]');if(!b)return;if(!confirm('Back up your MO2 profile, then open the normal MO2 installer? Review FOMOD and overwrite choices.'))return;b.disabled=true;try{const r=await bridgeRequest('POST','install',{downloadId:Number(b.dataset.downloadId),confirm:'INSTALL'});toast(r.message||'MO2 install complete');await refreshDownloads();const s=await bridgeRequest('GET','snapshot');activateLiveCatalog(s.catalog);await refreshGame()}catch(ex){toast('Install: '+ex.message)}finally{b.disabled=false}});
$('liveQuick').onclick=()=>scanLive('quick');$('liveDeep').onclick=()=>scanLive('deep');$('liveLocal').onclick=()=>scanLive('local');$('liveAll').onclick=()=>scanLive('all');
$('liveRefresh').onclick=async()=>{try{const r=await bridgeRequest('POST','refresh');activateLiveCatalog(r.catalog);await refreshWorkshop();await refreshGame();toast('⟳ Live profile refreshed')}catch(ex){toast(ex.message)}};
$('liveBackup').onclick=async()=>{if(!confirm('Create a timestamped backup of this MO2 profile’s text load-order state?'))return;try{const r=await bridgeRequest('POST','backup',{confirm:'BACKUP'});toast('⛨ Backed up '+r.files.length+' profile files.')}catch(ex){toast('Backup: '+ex.message)}};
$('liveRuntime').onclick=async()=>{try{const r=await bridgeRequest('POST','runtime');activateLiveCatalog(r.catalog);await refreshGame();toast('⚙ Target runtime updated')}catch(ex){toast(ex.message)}};
$('liveConnect').onclick=async()=>{try{const r=await bridgeRequest('POST','nexus-connect');toast(r.message)}catch(ex){toast(ex.message)}};
window.addEventListener('storage',e=>{if(e.key===STORAGE){STORE=structuredClone(BASE);load();$('search').value=STORE.prefs.query;applyAppearance();render();toast('↻ Changes synchronized from another Arsenal tab.')}});
load();applyAppearance();updateStorageIndicator();render();
// Development/test trace, harmless in release; does not expose filesystem privileges.
if(BRIDGE.active){initLiveBridge();setInterval(async()=>{if(document.hidden||LIVE_REFRESH_BUSY||!LIVE_CATALOG)return;LIVE_REFRESH_BUSY=true;try{const revision=await bridgeRequest('GET','revision');if(revision.generation!==LIVE_GENERATION){const snap=await bridgeRequest('GET','snapshot');LIVE_GENERATION=snap.generation;activateLiveCatalog(snap.catalog);toast('⟳ MO2 changes synchronized');}if(revision.profileId===LIVE_CATALOG?.profileId&&NATIVE_SELECTED!==revision.selectedModId){NATIVE_SELECTED=revision.selectedModId||'';paintNativeSelection();if(NATIVE_SELECTED)window.AetherFX?.select($('row-'+NATIVE_SELECTED),{source:'mo2'})}await refreshGame();if($('liveDownloadList').children.length)await refreshDownloads()}catch(ex){SET('liveSync','Bridge disconnected: '+ex.message)}finally{LIVE_REFRESH_BUSY=false}},4200)}
window.__ARSENAL_QA__={game:()=>GAME,refreshGame,previewVictory:()=>launchVictory({verifiedMods:DATA.items.length,bonus:0,updates:counts().done},true),getVictory:()=>({active:!$('victoryOverlay').hidden,title:$('victoryTitle').innerText}),closeVictory,locate:locateInMO2,live:BRIDGE.active,setCatalog:activateLiveCatalog,finisher:(name,x,y)=>{STORE.prefs.effect=name;spawnFinisher({x,y})},count:DATA.items.length,groups:DATA.groups.length,getSnapshot:()=>({counts:counts(),search:STORE.prefs.query,filter:STORE.prefs.filter}),aether:()=>window.AetherFX?.getState(),previewAether:()=>window.AetherFX?.preview(),getCatalog:()=>DATA,verifyRow:(id)=>({id,exists:ITEM_MAP.has(id),state:getRow(id)})};
})();
