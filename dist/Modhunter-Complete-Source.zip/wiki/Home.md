<div align="center">

# ⚔️ MODHUNTER
### THE UNFINISHED WORLD

**Repair your load order · Hunt unfinished mods · Build a legend**

![Version](https://img.shields.io/badge/Atlas-v0.8-cfa76d?style=for-the-badge&labelColor=17272c)
![Play](https://img.shields.io/badge/Play-Offline-70d6b0?style=for-the-badge&labelColor=17272c)
![Integrations](https://img.shields.io/badge/MO2-Optional-9abcf5?style=for-the-badge&labelColor=17272c)

</div>

![Modhunter hero](https://raw.githubusercontent.com/Herbertofury/Modhunter/main/screenshots/modhunter-menu.png)

> **Welcome, Hunter.** Your unfinished mod list is more than a maintenance backlog. It becomes your bestiary, quests and battles.

| Enter the world | Standalone requirement | Optional link |
| :-- | :-- | :-- |
| **[Portable HTML](https://github.com/Herbertofury/Modhunter/blob/main/web/Modhunter.html)** | A modern browser | MO2 localhost |
| **[Desktop App](Desktop-App.md)** | Node.js / Electron for source build | MO2 localhost |
| **[MO2 Plugin](MO2-Plugin.md)** | Mod Organizer 2 | Desktop or browser |

## 🌌 The realms

| Game | Identity |
| :-- | :-- |
| **Modhunter Siege** | Survivor roguelite with 5 classes, 22 upgrades, 6 weapon evolutions and boss fights |
| **Atlas Campaign** | 12 regions, 96 authored contracts, 5 mastery tiers, 480 first-clear milestones |
| **Shiverfell Chronicles** | Persistent top-down exploration, crafting, weather, companions and quests |
| **Update Workshop** | Full MO2 profile audit, native Nexus login, public GitHub/GitLab release checks, reviewed Nexus/GitHub downloads, and interactive MO2 installs |

## 📖 Field guide

**[Complete Original Release Vault](Original-Releases-and-Output-Audit.md)** · **[Update Workshop](Update-Workshop.md)** · **[Updater Source Coverage](Updater-Source-Coverage.md)** · **[Getting Started](Getting-Started.md)** · **[Game Modes](Game-Modes.md)** · **[Atlas Campaign](Atlas-Campaign.md)** · **[Unfinished Bestiary](Unfinished-Bestiary.md)** · **[Rewards & Integrity](Rewards-and-Integrity.md)** · **[Architecture](Architecture.md)** · **[Troubleshooting](Troubleshooting.md)**

## 📦 Eight original releases. No missing historical ZIPs or GIFs.

**[Browse the authentic original-release vault](Original-Releases-and-Output-Audit.md)**, with every v0.1–v0.8 HTML, plugin/source archive, four original gameplay GIFs, the original victory PNG, original Atlas map, release manifests and latest checked update packages. [Download the complete 58 MB bundle from Google Drive](https://drive.google.com/file/d/1tQBnUZ_vDF7tUTtiXf8WJC41OEXNVG_5/view).

## A single world, three independent gateways

The HTML is an entirely portable play surface. The desktop app is a dedicated multi-tab Chromium shell. The MO2 plugin alone owns live profile inspection and verified update rewards. Optional loopback communication allows them to share the same active game/profile identity without requiring any of the other installations.

**Release preservation:** all 36 original v0.1–v0.8 deliverables, including the authentic GIFs and historical source/plugin ZIPs, are recovered and SHA-256 audited. The later updater expansion passed 99 Python plus four Node desktop-import tests in CI. Native Windows MO2 and Electron acceptance testing remain to be performed.
